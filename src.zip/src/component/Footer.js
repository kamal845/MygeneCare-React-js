
import React from 'react';
import { Link } from 'react-router-dom'
export default function Footer() {
    return (
        <>
<footer id="footer-3" className="wide-40 footer division">
				<div className="container">


					{/* FOOTER CONTENT */}
					<div className="row">	


						{/* FOOTER INFO */}
						<div className="col-md-6 col-lg-4">
							<div className="footer-info mb-40">

								{/* Footer Logo */}
								{/* For Retina Ready displays take a image with double the amount of pixels that your image will be displayed (e.g 360 x 80  pixels) */}
								<a href="index.php"><img src="assets/images/logo.png" alt="" /></a>

								{/* Text */}	
								<p className="p-sm mt-20">Aliquam orci nullam tempor sapien gravida donec an enim ipsum porta
								   justo velna auctor congue magna laoreet augue sapien gravida at purus euismod 
								</p>

								{/* Social Icons */}
								<div className="footer-socials-links mt-20">
									<ul className="foo-socials text-center clearfix">

										<li><a href="#" className="ico-facebook"><i className="fa fa-facebook-f"></i></a></li>
										<li><a href="#" className="ico-tumblr"><i className="fa fa-instagram"></i></a></li>
										<li><a href="#" className="ico-twitter"><i className="fa fa-twitter"></i></a></li>	
										<li><a href="#" className="ico-google-plus"><i className="fa fa-google"></i></a></li>

									</ul>									
								</div> 
								
							</div>	
						</div>


						{/* FOOTER CONTACTS */}
						<div className="col-md-6 col-lg-3 offset-lg-1">
							<div className="footer-box mb-40">
							
								{/* Title */}
								<h5 className="h5-xs">Our Location</h5>

								{/* Address */}
								<p>G-130, sector-63, Noida</p> 
								<p>Uttar Pradesh : 201301</p>
								
								{/* Email */}
								<p className="foo-email mt-20"><i className="fa fa-envelope"></i> <a href="mailto:yourdomain@mail.com">hello@yourdomain.com</a></p>

								{/* Phone */}
								<p><a href="tel:+91 1234567811"><i className="fa fa-phone"></i> +91 1234567811</a></p>

							</div>
						</div>


						{/* FOOTER LINKS */}
						<div className="col-md-6 col-lg-2">
							<div className="footer-links mb-40">
							
								{/* Title */}
								<h5 className="h5-xs">About Clinic</h5>

								{/* Footer Links */}
								<ul className="foo-links clearfix">
									<li><Link to="about">About Us</Link></li>
									<li><Link to="about">Partnerships</Link></li>
									<li><Link to="nft">NFT Market</Link></li>
									<li><Link to="product">Product & Services</Link></li>
									<li><Link to="contact">Contact Us</Link></li>									
								</ul>

							</div>
						</div>


						{/* FOOTER LINKS */}
						<div className="col-md-6 col-lg-2">
							<div className="footer-links mb-40">
												
								{/* Title */}
								<h5 className="h5-xs">Discover</h5>

								{/* Footer List */}
								<ul className="clearfix">																		
									<li><Link to="mgcc">MGCC Digital Currency</Link></li>																				
									<li><Link to="profile">Cart</Link></li>
									<li><Link to="mgcc">MGCC Economics</Link></li>
									<li><Link to="mgcc">FAQs</Link></li>
									<li><Link to="terms">Terms & Condition</Link></li>								
								</ul>

							</div>
						</div>	


					</div>	  {/* END FOOTER CONTENT */}


					{/* FOOTER COPYRIGHT */}
					<div className="bottom-footer">
						<div className="row">
							<div className="col-md-12">
								<p className="footer-copyright">&copy; 2021 <span>MyGeneCare</span>. All Right Reserved <a href="https://aanaxagorasr.com/" target="_blank">Aanaxagorasr</a> Software Pvt. Ltd</p>
							</div>
						</div>
					</div>


				</div>	   {/* End container */}
			</footer>	
  
        </>
    )
}

