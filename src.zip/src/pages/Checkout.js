
import React from 'react';
import { Link } from 'react-router-dom'
export default function Checkout() {
    return (
        <>
            
            <div id="page" className="page">




{/* HEADER
    ============================================= */}
{/* END HEADER */}




{/* BREADCRUMB
    ============================================= */}
<div id="breadcrumb" className="division">
    <div className="container">
        <div className="row">
            <div className="col">
                <div className=" breadcrumb-holder">

                    {/* Breadcrumb Nav */}
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li className="breadcrumb-item active" aria-current="page">Checkout</li>
                        </ol>
                    </nav>

                    {/* Title */}
                    <h4 className="h4-sm steelblue-color">Checkout</h4>

                </div>
            </div>
        </div> {/* End row */}
    </div> {/* End container */}
</div> {/* END BREADCRUMB */}




<section className="pt-100 tabs-section division">
    <div className="container">	
         <div className="row">
            <div className="col-lg-10 offset-lg-1 section-title">		

                {/* Title 	*/}	
                <h3 className="h3-md steelblue-color">Update Your Profile</h3>	

                {/* Text */}
                <p>Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis libero at tempus, 
                   blandit posuere ligula varius congue cursus porta feugiat
                </p>
                            
            </div>
             <div className="col-md-12">
                 

                 {/* TABS NAVIGATION */}
                <div id="tabs-nav" className="list-group text-center profile-tabs">
                    <ul className="nav nav-pills" id="pills-tab" role="tablist">

                        {/* TAB-1 LINK */}
                          <li className="nav-item icon-xs">
                            <a className="nav-link active" id="tab1-list" data-toggle="pill" href="#tab-1" role="tab" aria-controls="tab-1" aria-selected="true">
                                <i className="fa fa-user"></i> Checkout
                            </a>
                          </li>

                          {/* TAB-2 LINK */}
                        <li className="nav-item icon-xs">
                            <a className="nav-link" id="tab2-list" data-toggle="pill" href="#tab-2" role="tab" aria-controls="tab-2" aria-selected="false">
                                <i className="fa fa-cart-arrow-down" aria-hidden="true"></i> Cart
                            </a>
                        </li>

                        {/* TAB-3 LINK */}
                        <li className="nav-item icon-xs">
                            <a className="nav-link" id="tab3-list" data-toggle="pill" href="#tab-3" role="tab" aria-controls="tab-3" aria-selected="false">
                                <i className="fa fa-check" aria-hidden="true"></i> Orders
                            </a>
                        </li>

                        {/* TAB-4 LINK */}
                        <li className="nav-item icon-xs">
                            <a className="nav-link" id="tab4-list" data-toggle="pill" href="#tab-4" role="tab" aria-controls="tab-4" aria-selected="false">
                                <i className="fa fa-map-marker" aria-hidden="true"></i> Appointments
                            </a>
                        </li>

                            {/* TAB-5 LINK */}
                            <li className="nav-item icon-xs">
                                <a className="nav-link" id="tab5-list" data-toggle="pill" href="#tab-5" role="tab" aria-controls="tab-4" aria-selected="false">
                                    <i className="fa fa-calendar" aria-hidden="true"></i> Change Address
                                </a>
                            </li>

                    </ul>

                </div>	{/* END TABS NAVIGATION */}


                {/* TABS CONTENT */}
                <div className="tab-content profile-tab-content" id="pills-tabContent">


                    {/* TAB-1 CONTENT */}
                    <div className="tab-pane fade show active" id="tab-1" role="tabpanel" aria-labelledby="tab1-list">
                        <div className="row d-flex align-items-center">


                            {/* TAB-1 IMAGE */}
                           <div className="col-lg-6">
                               <div className="profile-detail">
                                   <img src="assets/images/profile.png" alt="" />
                                   <div className="form-inline">
                                       <h5>Name: </h5>
                                       <span>Radhe Shyam</span>
                                   </div>
                                   <div className="form-inline">
                                    <h5>Email: </h5>
                                    <span>Rayam@gmail.com</span>
                                </div>
                                <div className="form-inline">
                                    <h5>Phone: </h5>
                                    <span>+91 1223455</span>
                                </div>
                                <div className="form-inline">
                                    <h5>Password: </h5>
                                    <span>**********</span>
                                </div>
                                <div className="form-inline">
                                    <h5>Address: </h5>
                                    <span>G-130, sector-63, Noida

                                        Uttar Pradesh : 201301</span>
                                </div>
                               </div>
                           </div>


                            {/* TAB-1 TEXT */}
                            <div className="col-lg-6">
                               <div className="profile-change-form">
                                   <h3>Change Your Profile Details From Here.</h3>
                                   <form action="">
                                       <div className="row">
                                           <div className="col-lg-6">
                                               <div className="form-group">
                                                   <input type="text" name="" id="" placeholder="Full name" className="form-control" />
                                               </div>
                                           </div>
                                           <div className="col-lg-6">
                                            <div className="form-group">
                                                <input type="email" name="" id="" placeholder="Email address" className="form-control" />
                                            </div>
                                        </div>
                                        <div className="col-lg-6">
                                            <div className="form-group">
                                                <input type="text" name="" id="" placeholder="Phone no." className="form-control" />
                                            </div>
                                        </div>
                                        <div className="col-lg-6">
                                            <div className="form-group">
                                                <input type="password" name="" id="" placeholder="Old password" className="form-control" />
                                            </div>
                                        </div>
                                        <div className="col-lg-6">
                                            <div className="form-group">
                                                <input type="password" name="" id="" placeholder="New password" className="form-control" />
                                            </div>
                                        </div>
                                        <div className="col-lg-6">
                                            <div className="form-group">
                                                <input type="password" name="" id="" placeholder="Confirm password" className="form-control" />
                                            </div>
                                        </div>
                                        <div className="col-lg-12">
                                            <div className="form-group">
                                                <button type="submit" className="btn btn-blue tra-white-hover ml-auto">Save Changes</button>
                                            </div>
                                        </div>
                                       </div>
                                   </form>
                               </div>	
                            </div>	{/* END TAB-1 TEXT */}


                        </div>
                    </div>	{/* END TAB-1 CONTENT */}


                    {/* TAB-2 CONTENT */}
                    <div className="tab-pane fade" id="tab-2" role="tabpanel" aria-labelledby="tab2-list">
                        <div className="row d-flex align-items-center">


                            <div className="col-lg-12">
                                <div className="cart-table table-responsive">
                                    <table className="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>Product</th>
                                                <th>Product name</th>
                                                <th>Price</th>
                                                <th>Quantity</th>
                                                <th>Shipping charges</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td><img src="assets/images/prod.png" alt="" /></td>
                                                <td>Whole Genome Sequencing</td>
                                                <td><i className="fa fa-inr"></i> 399</td>
                                                <td><input type="number" name="" id="" /></td>
                                                <td><i className="fa fa-inr"></i> 500</td>
                                                <td><h6 id="remove">Remove</h6></td>
        
                                            </tr>
                                            <tr>
                                                <td><img src="assets/images/prod.png" alt="" /></td>
                                                <td>Whole Genome Sequencing</td>
                                                <td><i className="fa fa-inr"></i> 399</td>
                                                <td><input type="number" name="" id="" /></td>
                                                <td><i className="fa fa-inr"></i> 500</td>
                                                <td><h6 id="remove">Remove</h6></td>
        
                                            </tr>
                                            <tr>
                                                <td><img src="assets/images/prod.png" alt="" /></td>
                                                <td>Whole Genome Sequencing</td>
                                                <td><i className="fa fa-inr"></i> 399</td>
                                                <td><input type="number" name="" id="" /></td>
                                                <td><i className="fa fa-inr"></i> 500</td>
                                                <td><h6 id="remove">Remove</h6></td>
        
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <br />
                            <div className="col-lg-6 col-sm-5">
                                <div className="cart-img">
                                    <img src="assets/images/cart-left.jpg" alt="" />
                                </div>
                            </div>
                            <div className="col-lg-6 col-sm-7">
                                <div className="cart-chart">
                                    <div className="form-inline product-count">
                                        <h4>Products</h4>
                                        <span><h4>Price</h4></span>
                                    </div>
                                    <hr />
                                    <div className="form-inline">
                                        <p>Whole Genome Sequencing</p>
                                        <span><i className="fa fa-inr"></i> 1599/-</span>
                                    </div>
                                    <div className="form-inline">
                                        <p>Whole Genome Sequencing</p>
                                        <span><i className="fa fa-inr"></i> 1599/-</span>
                                    </div>
                                    <div className="form-inline">
                                        <p>Whole Genome Sequencing</p>
                                        <span><i className="fa fa-inr"></i> 1599/-</span>
                                    </div>
                                    <hr />
                                    <div className="form-inline">
                                        <h4>Total Price</h4>
                                        <span><h4><i className="fa fa-inr"></i> 4500/-</h4></span>
                                    </div>
                                    <br />
                                    <div className="form-inline">
                                        <a href="checkout.php" className="btn btn-blue tra-white-hover ml-auto">Checkout</a>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>	{/* END TAB-2 CONTENT */}


                    {/* TAB-3 CONTENT */}
                    <div className="tab-pane fade" id="tab-3" role="tabpanel" aria-labelledby="tab3-list">
                        <div className="row d-flex align-items-center">


                            <div className="col-lg-12">
                                <div className="cart-table table-responsive">
                                  <table className="table table-bordered table-striped table-hover">
                                      <thead>
                                        <tr>
                                            <th>Product</th>
                                          <th>Product name</th>
                                          <th>Price</th>
                                          <th>Quantity</th>
                                          <th>Shipping charges</th>
                                          <th>Status</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        <tr>
                                          <td><img src="assets/images/prod.png" alt="" /></td>
                                          <td>Fidget Cube</td>
                                          <td><i className="fa fa-inr"></i> 399</td>
                                          <td>2</td>
                                          <td><i className="fa fa-inr"></i> 500</td>
                                          <td>Success</td>
                  
                                        </tr>
                                        <tr>
                                          <td><img src="assets/images/prod.png" alt="" /></td>
                                          <td>Fidget Cube</td>
                                          <td><i className="fa fa-inr"></i> 399</td>
                                          <td>3</td>
                                          <td><i className="fa fa-inr"></i> 500</td>
                                          <td>Success</td>
                  
                                        </tr>
                                        <tr>
                                          <td><img src="assets/images/prod.png" alt="" /></td>
                                          <td>Fidget Cube</td>
                                          <td><i className="fa fa-inr"></i> 399</td>
                                          <td>3</td>
                                          <td><i className="fa fa-inr"></i> 500</td>
                                          <td>Success</td>
                  
                                        </tr>
                                      </tbody>
                                    </table>
                                </div>
                                </div>

                            
                        </div>
                    </div>	{/* END TAB-3 CONTENT */}


                    {/* TAB-4 CONTENT */}
                    <div className="tab-pane fade" id="tab-4" role="tabpanel" aria-labelledby="tab4-list">
                        <div className="row d-flex align-items-center">


                            <div className="col-lg-12">
                                <div className="cart-table table-responsive">
                                  <table className="table table-bordered table-striped table-hover">
                                      <thead>
                                        <tr>
                                            <th>Serial no.</th>
                                          <th>Doctor name</th>
                                          <th>Appointment date</th>
                                        </tr>
                                      </thead>
                                      <tbody>
                                        <tr>
                                          <td>1</td>
                                          <td>Mr. Rajesh</td>
                                          <td>21/Nov/2021</td>
                  
                                        </tr>
                                        <tr>
                                            <td>1</td>
                                            <td>Mr. Rajesh</td>
                                            <td>21/Nov/2021</td>
                    
                                          </tr>
                                      </tbody>
                                    </table>
                                </div>
                                </div>

                            
                        </div>
                    </div>	{/* END TAB-4 CONTENT */}


                    
                    {/* TAB-5 CONTENT */}
                    <div className="tab-pane fade" id="tab-5" role="tabpanel" aria-labelledby="tab5-list">
                        <div className="row d-flex align-items-center">


                                {/* TAB-1 IMAGE */}
                           <div className="col-lg-6">
                            <div className="profile-detail">
                                <img src="assets/images/profile.png" alt="" />
                                <div className="form-inline">
                                    <h5>Name: </h5>
                                    <span>Radhe Shyam</span>
                                </div>
                                <div className="form-inline">
                                 <h5>Email: </h5>
                                 <span>Rayam@gmail.com</span>
                             </div>
                             <div className="form-inline">
                                 <h5>Phone: </h5>
                                 <span>+91 1223455</span>
                             </div>
                             <div className="form-inline">
                                 <h5>Password: </h5>
                                 <span>**********</span>
                             </div>
                             <div className="form-inline">
                                 <h5>Address: </h5>
                                 <span>G-130, sector-63, Noida

                                     Uttar Pradesh : 201301</span>
                             </div>
                            </div>
                        </div>


                         {/* TAB-1 TEXT */}
                         <div className="col-lg-6">
                            <div className="profile-change-form">
                                <h3>Change Your Address From Here.</h3>
                                <form action="">
                                    <div className="row">
                                        <div className="col-lg-6">
                                            <div className="form-group">
                                                <input type="text" name="" id="" placeholder="Stree line 1" className="form-control" />
                                            </div>
                                        </div>
                                        <div className="col-lg-6">
                                         <div className="form-group">
                                             <input type="email" name="" id="" placeholder="Stree line 2" className="form-control" />
                                         </div>
                                     </div>
                                     <div className="col-lg-6">
                                         <div className="form-group">
                                             <input type="text" name="" id="" placeholder="Country" className="form-control" />
                                         </div>
                                     </div>
                                     <div className="col-lg-6">
                                         <div className="form-group">
                                             <input type="password" name="" id="" placeholder="State" className="form-control" />
                                         </div>
                                     </div>
                                     <div className="col-lg-12">
                                         <div className="form-group">
                                             <input type="password" name="" id="" placeholder="Pincode" className="form-control" />
                                         </div>
                                     </div>
                                     <div className="col-lg-12">
                                         <div className="form-group">
                                             <button type="submit" className="btn btn-blue tra-white-hover ml-auto">Save Changes</button>
                                         </div>
                                     </div>
                                    </div>
                                </form>
                            </div>	
                         </div>	{/* END TAB-1 TEXT */}

                            
                        </div>
                    </div>	{/* END TAB-5 CONTENT */}


                </div>	{/* END TABS CONTENT */}


             </div>	
         </div>     {/* End row */}	
    </div>     {/* End container */}	
</section>




{/* FOOTER-3
    ============================================= */}
{/* END FOOTER-3 */}


{/* The Modal */}

</div>
  
        </>
    )
}

