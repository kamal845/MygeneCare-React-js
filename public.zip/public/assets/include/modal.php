<div class="modal slide" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
      
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Registration Form For Doctor</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        
        <!-- Modal body -->
        <div class="modal-body">
         <form action="" class="custom-form">
			<div class="row">
				<div class="col-lg-12">
					<div class="form-group">
						<input type="text" name="" id="" placeholder="Full name" class="form-control">
					</div>
				</div>
		
			<div class="col-lg-12">
				<div class="form-group">
					<input type="email" name="" id="" placeholder="Enter your email here" class="form-control">
				</div>
			</div>
			<div class="col-lg-12">
				<div class="form-group">
					<input type="tel" name="" id="" placeholder="Phone no." class="form-control">
				</div>
			</div>
			<div class="col-lg-12">
				<div class="form-group">
					<select name="" id="" class="form-control">
						<option value="">Whole Genome Sequencing</option>
						<option value="">Whole Exome Sequencing</option>
						<option value="">Gentotypimg</option>
-						<option value="">Pharmacogenomics</option>
						<option value="">Egg or Sperm Selection</option>
					</select>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="form-group">
					<input type="text" name="" id="" placeholder="Full Address" class="form-control">
				</div>
			</div>
			<div class="col-lg-12">
				<div class="form-group">
					<input type="Pincode" name="" id="" placeholder="City" class="form-control">
				</div>
			</div>
			<div class="col-lg-12">
				<div class="form-group">
					<input type="Pincode" name="" id="" placeholder="Pin code" class="form-control">
				</div>
			</div>
			<div class="col-lg-12">
				<div class="doctor-Registration-btn text-center">
					<a href="" class="btn btn-blue">Register</a>
				</div>
			</div>
		</div>
		 </form>
        </div>
        
        
      </div>
    </div>
  </div>