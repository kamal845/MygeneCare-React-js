<footer id="footer-3" class="wide-40 footer division">
				<div class="container">


					<!-- FOOTER CONTENT -->
					<div class="row">	


						<!-- FOOTER INFO -->
						<div class="col-md-6 col-lg-4">
							<div class="footer-info mb-40">

								<!-- Footer Logo -->
								<!-- For Retina Ready displays take a image with double the amount of pixels that your image will be displayed (e.g 360 x 80  pixels) -->
								<a href="index.php"><img src="assets/images/logo.png" alt=""></a>

								<!-- Text -->	
								<p class="p-sm mt-20">Aliquam orci nullam tempor sapien gravida donec an enim ipsum porta
								   justo velna auctor congue magna laoreet augue sapien gravida at purus euismod 
								</p>

								<!-- Social Icons -->
								<div class="footer-socials-links mt-20">
									<ul class="foo-socials text-center clearfix">

										<li><a href="#" class="ico-facebook"><i class="fa fa-facebook-f"></i></a></li>
										<li><a href="#" class="ico-tumblr"><i class="fa fa-instagram"></i></a></li>
										<li><a href="#" class="ico-twitter"><i class="fa fa-twitter"></i></a></li>	
										<li><a href="#" class="ico-google-plus"><i class="fa fa-google"></i></a></li>

									</ul>									
								</div> 
								
							</div>	
						</div>


						<!-- FOOTER CONTACTS -->
						<div class="col-md-6 col-lg-3 offset-lg-1">
							<div class="footer-box mb-40">
							
								<!-- Title -->
								<h5 class="h5-xs">Our Location</h5>

								<!-- Address -->
								<p>G-130, sector-63, Noida</p> 
								<p>Uttar Pradesh : 201301</p>
								
								<!-- Email -->
								<p class="foo-email mt-20"><i class="fa fa-envelope"></i> <a href="mailto:yourdomain@mail.com">hello@yourdomain.com</a></p>

								<!-- Phone -->
								<p><a href="tel:+91 1234567811"><i class="fa fa-phone"></i> +91 1234567811</a></p>

							</div>
						</div>


						<!-- FOOTER LINKS -->
						<div class="col-md-6 col-lg-2">
							<div class="footer-links mb-40">
							
								<!-- Title -->
								<h5 class="h5-xs">About Clinic</h5>

								<!-- Footer Links -->
								<ul class="foo-links clearfix">
									<li><a href="about.php">About Us</a></li>
									<li><a href="about.php">Partnerships</a></li>
									<li><a href="about.php">NFT Market</a></li>
									<li><a href="product.php">Product & Services</a></li>
									<li><a href="contact.php">Contact Us</a></li>									
								</ul>

							</div>
						</div>


						<!-- FOOTER LINKS -->
						<div class="col-md-6 col-lg-2">
							<div class="footer-links mb-40">
												
								<!-- Title -->
								<h5 class="h5-xs">Discover</h5>

								<!-- Footer List -->
								<ul class="clearfix">																		
									<li><a href="#">MGCC Digital Currency</a></li>																				
									<li><a href="#">Cart</a></li>
									<li><a href="#">MGCC Economics</a></li>
									<li><a href="#">FAQs</a></li>
									<li><a href="#">Terms & Condition</a></li>								
								</ul>

							</div>
						</div>	


					</div>	  <!-- END FOOTER CONTENT -->


					<!-- FOOTER COPYRIGHT -->
					<div class="bottom-footer">
						<div class="row">
							<div class="col-md-12">
								<p class="footer-copyright">&copy; 2021 <span>MyGeneCare</span>. All Right Reserved <a href="https://aanaxagorasr.com/">Aanaxagorasr</a> Software Pvt. Ltd</p>
							</div>
						</div>
					</div>


				</div>	   <!-- End container -->
			</footer>	