
import './App.css';
import Header from './component/Header';
import Footer from './component/Footer';
import Home from './pages/Home';
import About from './pages/About';
import Contact from './pages/Contact';
import Product from './pages/Product';
import Appointment from './pages/Appointment';
import Nft from './pages/Nft';
import Profile from './pages/Profile';
import Alldoctor from './pages/Alldoctor';
import Checkout from './pages/Checkout';
import Aidata from './pages/Aidata';


import{BrowserRouter,Routes,Route, Link} from 'react-router-dom';



function App() {
  return (
    <>
    <BrowserRouter>
<Header/>

<Routes>
<Route path="/" exact element={<Home/>}exact />
<Route path="/home" element={<Home/>}exact />
<Route path="/about" element={<About/>}exact />
<Route path="/contact" element={<Contact/>}exact />
<Route path="/product" element={<Product/>}exact />
<Route path="/appointment" element={<Appointment/>}exact />
<Route path="/nft" element={<Nft/>}exact />
<Route path="/profile" element={<Profile/>}exact />
<Route path="/alldoctor" element={<Alldoctor/>}exact />
<Route path="/checkout" element={<Checkout/>}exact />
<Route path="/aidata" element={<Aidata/>}exact />
</Routes>

<Footer/>
    




       </BrowserRouter>
    </>
  );
}

export default App;
