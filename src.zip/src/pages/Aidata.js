
import React from 'react';
import { Link } from 'react-router-dom'
export default function Aidata() {
    return (
        <>
            
            <div id="page" className="page">




{/* HEADER
    ============================================= */}
{/* END HEADER */}




{/* BREADCRUMB
    ============================================= */}
<div id="breadcrumb" className="division">
    <div className="container">
        <div className="row">
            <div className="col">
                <div className=" breadcrumb-holder">

                    {/* Breadcrumb Nav */}
                    <nav aria-label="breadcrumb">
                        <ol className="breadcrumb">
                            <li className="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li className="breadcrumb-item active" aria-current="page">Ai & Data</li>
                        </ol>
                    </nav>

                    {/* Title */}
                    <h4 className="h4-sm steelblue-color">Ai & Data</h4>

                </div>
            </div>
        </div> {/* End row */}
    </div> {/* End container */}
</div> {/* END BREADCRUMB */}









</div>
  
        </>
    )
}

