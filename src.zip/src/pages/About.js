
import React from 'react';
import { Link } from 'react-router-dom'
export default function About() {
    return (
        <>
            <div id="page" className="page">





                <div id="breadcrumb" className="division">
                    <div className="container">
                        <div className="row">-
                            <div className="col">
                                <div className=" breadcrumb-holder">

                                    {/* Breadcrumb Nav */}
                                    <nav aria-label="breadcrumb">
                                        <ol className="breadcrumb">
                                            <li className="breadcrumb-item"><a href="index.php">Home</a></li>
                                            <li className="breadcrumb-item active" aria-current="page">About Us</li>
                                        </ol>
                                    </nav>

                                    {/* Title */}
                                    <h4 className="h4-sm steelblue-color">About Us</h4>

                                </div>
                            </div>
                        </div>  {/* End row */}
                    </div>	{/* End container */}
                </div>	{/* END BREADCRUMB */}




                {/* INFO-4
    ============================================= */}
                <section id="info-4" className="wide-100 info-section division">
                    <div className="container">


                        {/* TOP ROW */}
                        <div className="top-row">
                            <div className="row d-flex align-items-center">


                                {/* INFO IMAGE */}
                                <div className="col-lg-6">
                                    <div className="info-4-img text-center wow fadeInUp" data-wow-delay="0.6s">
                                        <img className="img-fluid" src="assets/images/about.jpg" alt="info-image" />
                                    </div>
                                </div>


                                {/* INFO TEXT */}
                                <div className="col-lg-6">
                                    <div className="txt-block pc-30 wow fadeInUp" data-wow-delay="0.4s">

                                        {/* Section ID */}
                                        <span className="section-id blue-color">Welcome to MyGeneCare</span>

                                        {/* Title */}
                                        <h3 className="h3-md steelblue-color">Clinic with Innovative Approach to Treatment</h3>

                                        {/* Text */}
                                        <p>An enim nullam tempor sapien gravida donec pretium ipsum  porta justo integer at  odio
                                            velna vitae auctor integer congue magna purus pretium ligula rutrum luctus ultrice aliquam
                                            a augue suscipit
                                        </p>

                                        {/* Text */}
                                        <p>Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor tempus feugiat
                                            dolor lacinia cubilia curae integer congue leo metus, eu mollislorem primis in orci integer
                                            metus mollis faucibus. An enim nullam tempor sapien gravida donec pretium and ipsum porta
                                            justo integer at velna vitae auctor integer congue
                                        </p>

                                    </div>
                                </div>	{/* END TEXT BLOCK */}


                            </div>    {/* End row */}
                        </div>	{/* END TOP ROW */}


                    </div>	   {/* End container */}
                </section>	{/* END INFO-4 */}


                {/* BANNER-5
    ============================================= */}
                <section id="banner-5" className="pb-50 banner-section division">
                    <div className="container">


                        {/* SECTION TITLE */}
                        <div className="row">
                            <div className="col-lg-10 offset-lg-1 section-title">

                                {/* Title 	*/}
                                <h3 className="h3-md steelblue-color">Our Team</h3>

                                {/* Text */}
                                <p>Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis libero at tempus,
                                    blandit posuere ligula varius congue cursus porta feugiat
                                </p>

                            </div>
                        </div>


                        <div className="row">
                            {/* DOCTOR #1 */}
                            <div className="col-md-6 col-lg-4">
                                <div className="doctor-2">

                                    {/* Doctor Photo */}
                                    <div className="hover-overlay">
                                        <img className="img-fluid" src="assets/images/doctor-1.jpg" alt="doctor-foto" />
                                    </div>

                                    {/* Doctor Meta */}
                                    <div className="doctor-meta">

                                        <h5 className="h5-xs blue-color">Jonathan Barnes D.M.</h5>
                                        <span>Chief Medical Officer</span>


                                    </div>

                                </div>
                            </div>	{/* END DOCTOR #1 */}


                            {/* DOCTOR #2 */}
                            <div className="col-md-6 col-lg-4">
                                <div className="doctor-2">

                                    {/* Doctor Photo */}
                                    <div className="hover-overlay">
                                        <img className="img-fluid" src="assets/images/doctor-2.jpg" alt="doctor-foto" />
                                    </div>

                                    {/* Doctor Meta */}
                                    <div className="doctor-meta">

                                        <h5 className="h5-xs blue-color">Hannah Harper D.M.</h5>
                                        <span>Anesthesiologist</span>

                                    </div>

                                </div>
                            </div>	{/* END DOCTOR #2 */}


                            {/* DOCTOR #3 */}
                            <div className="col-md-6 col-lg-4">
                                <div className="doctor-2">

                                    {/* Doctor Photo */}
                                    <div className="hover-overlay">
                                        <img className="img-fluid" src="assets/images/doctor-3.jpg" alt="doctor-foto" />
                                    </div>

                                    {/* Doctor Meta */}
                                    <div className="doctor-meta">

                                        <h5 className="h5-xs blue-color">Matthew Anderson D.M.</h5>
                                        <span>Cardiology</span>

                                    </div>

                                </div>
                            </div>	{/* END DOCTOR #3 */}


                            {/* DOCTOR #4 */}
                            <div className="col-md-6 col-lg-4">
                                <div className="doctor-2">

                                    {/* Doctor Photo */}
                                    <div className="hover-overlay">
                                        <img className="img-fluid" src="assets/images/doctor-4.jpg" alt="doctor-foto" />
                                    </div>

                                    {/* Doctor Meta */}
                                    <div className="doctor-meta">

                                        <h5 className="h5-xs blue-color">Megan Coleman D.M.</h5>
                                        <span>Neurosurgeon</span>

                                    </div>

                                </div>
                            </div>	{/* END DOCTOR #4 */}


                            {/* DOCTOR #5 */}
                            <div className="col-md-6 col-lg-4">
                                <div className="doctor-2">

                                    {/* Doctor Photo */}
                                    <div className="hover-overlay">
                                        <img className="img-fluid" src="assets/images/doctor-5.jpg" alt="doctor-foto" />
                                    </div>

                                    {/* Doctor Meta */}
                                    <div className="doctor-meta">

                                        <h5 className="h5-xs blue-color">Robert Peterson D.M.</h5>
                                        <span>Allergist</span>

                                    </div>

                                </div>
                            </div>	{/* END DOCTOR #5 */}


                            {/* DOCTOR #6 */}
                            <div className="col-md-6 col-lg-4">
                                <div className="doctor-2">

                                    {/* Doctor Photo */}
                                    <div className="hover-overlay">
                                        <img className="img-fluid" src="assets/images/doctor-6.jpg" alt="doctor-foto" />
                                    </div>

                                    {/* Doctor Meta */}
                                    <div className="doctor-meta">

                                        <h5 className="h5-xs blue-color">Joshua Elledge D.M.</h5>
                                        <span>Orthopaedics</span>

                                    </div>

                                </div>
                            </div>	{/* END DOCTOR #6 */}


                            {/* DOCTOR #7 */}
                            <div className="col-md-6 col-lg-4">
                                <div className="doctor-2">

                                    {/* Doctor Photo */}
                                    <div className="hover-overlay">
                                        <img className="img-fluid" src="assets/images/doctor-3.jpg" alt="doctor-foto" />
                                    </div>

                                    {/* Doctor Meta */}
                                    <div className="doctor-meta">

                                        <h5 className="h5-xs blue-color">Matthew Anderson D.M.</h5>
                                        <span>Cardiology</span>

                                    </div>

                                </div>
                            </div>	{/* END DOCTOR #7 */}


                            {/* DOCTOR #8 */}
                            <div className="col-md-6 col-lg-4">
                                <div className="doctor-2">

                                    {/* Doctor Photo */}
                                    <div className="hover-overlay">
                                        <img className="img-fluid" src="assets/images/doctor-1.jpg" alt="doctor-foto" />
                                    </div>

                                    {/* Doctor Meta */}
                                    <div className="doctor-meta">

                                        <h5 className="h5-xs blue-color">Jonathan Barnes D.M.</h5>
                                        <span>Chief Medical Officer</span>

                                    </div>

                                </div>
                            </div>	{/* END DOCTOR #8 */}
                        </div>


                    </div>	   {/* End container */}
                </section>	{/* END BANNER-5 */}





                {/* SERVICES-7
    ============================================= */}
                <section id="services-7" className="bg-lightgrey wide-70 servicess-section division">
                    <div className="container">
                        <div className="row">

                            <div className="col-lg-10 offset-lg-1 section-title">

                                {/* Title 	*/}
                                <h3 className="h3-md steelblue-color">People Who Trust On Us</h3>

                                {/* Text */}
                                <p>Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis libero at tempus,
                                    blandit posuere ligula varius congue cursus porta feugiat
                                </p>

                            </div>


                            {/* SERVICE BOXES */}
                            <div className="col-lg-12">
                                <div className="row">


                                    {/* SERVICE BOX #1 */}
                                    <div className="col-lg-2 col-sm-6 col-xs-6">
                                        <div className="sbox-7 icon-xs wow fadeInUp" data-wow-delay="0.4s">
                                            <img src="assets/images/icons/Google-logo.png" alt="" />
                                        </div>
                                    </div>  {/* END SERVICE BOX #1 */}


                                    {/* SERVICE BOX #2 */}
                                    <div className="col-lg-2 col-sm-6 col-xs-6">
                                        <div className="sbox-7 icon-xs wow fadeInUp" data-wow-delay="0.4s">
                                            <img src="assets/images/icons/Google-logo.png" alt="" />
                                        </div>
                                    </div>  {/* END SERVICE BOX #2 */}


                                    {/* SERVICE BOX #3 */}
                                    <div className="col-lg-2 col-sm-6 col-xs-6">
                                        <div className="sbox-7 icon-xs wow fadeInUp" data-wow-delay="0.4s">
                                            <img src="assets/images/icons/Google-logo.png" alt="" />
                                        </div>
                                    </div>  {/* END SERVICE BOX #3 */}


                                    {/* SERVICE BOX #1 */}
                                    <div className="col-lg-2 col-sm-6 col-xs-6">
                                        <div className="sbox-7 icon-xs wow fadeInUp" data-wow-delay="0.4s">
                                            <img src="assets/images/icons/Google-logo.png" alt="" />
                                        </div>
                                    </div>  {/* END SERVICE BOX #1 */}


                                    {/* SERVICE BOX #1 */}
                                    <div className="col-lg-2 col-sm-6 col-xs-6">
                                        <div className="sbox-7 icon-xs wow fadeInUp" data-wow-delay="0.4s">
                                            <img src="assets/images/icons/Google-logo.png" alt="" />
                                        </div>
                                    </div>  {/* END SERVICE BOX #1 */}


                                    {/* SERVICE BOX #1 */}
                                    <div className="col-lg-2 col-sm-6 col-xs-6">
                                        <div className="sbox-7 icon-xs wow fadeInUp" data-wow-delay="0.4s">
                                            <img src="assets/images/icons/Google-logo.png" alt="" />
                                        </div>
                                    </div>  {/* END SERVICE BOX #1 */}

                                    {/* SERVICE BOX #1 */}
                                    <div className="col-lg-2 col-sm-6 col-xs-6">
                                        <div className="sbox-7 icon-xs wow fadeInUp" data-wow-delay="0.4s">
                                            <img src="assets/images/icons/Google-logo.png" alt="" />
                                        </div>
                                    </div>  {/* END SERVICE BOX #1 */}

                                    {/* SERVICE BOX #1 */}
                                    <div className="col-lg-2 col-sm-6 col-xs-6">
                                        <div className="sbox-7 icon-xs wow fadeInUp" data-wow-delay="0.4s">
                                            <img src="assets/images/icons/Google-logo.png" alt="" />
                                        </div>
                                    </div>  {/* END SERVICE BOX #1 */}

                                    {/* SERVICE BOX #1 */}
                                    <div className="col-lg-2 col-sm-6 col-xs-6">
                                        <div className="sbox-7 icon-xs wow fadeInUp" data-wow-delay="0.4s">
                                            <img src="assets/images/icons/Google-logo.png" alt="" />
                                        </div>
                                    </div>  {/* END SERVICE BOX #1 */}


                                    {/* SERVICE BOX #1 */}
                                    <div className="col-lg-2 col-sm-6 col-xs-6">
                                        <div className="sbox-7 icon-xs wow fadeInUp" data-wow-delay="0.4s">
                                            <img src="assets/images/icons/Google-logo.png" alt="" />
                                        </div>
                                    </div>  {/* END SERVICE BOX #1 */}

                                    {/* SERVICE BOX #1 */}
                                    <div className="col-lg-2 col-sm-6 col-xs-6">
                                        <div className="sbox-7 icon-xs wow fadeInUp" data-wow-delay="0.4s">
                                            <img src="assets/images/icons/Google-logo.png" alt="" />
                                        </div>
                                    </div>  {/* END SERVICE BOX #1 */}

                                    {/* SERVICE BOX #1 */}
                                    <div className="col-lg-2 col-sm-6 col-xs-6">
                                        <div className="sbox-7 icon-xs wow fadeInUp" data-wow-delay="0.4s">
                                            <img src="assets/images/icons/Google-logo.png" alt="" />
                                        </div>
                                    </div>  {/* END SERVICE BOX #1 */}


                                </div>
                            </div>	{/* END SERVICE BOXES */}




                        </div>    {/* End row */}
                    </div>	   {/* End container */}
                </section>	{/* END SERVICES-7 */}

                <section id="video-1" className="wide-60 video-section division">
                    <div className="container">
                        <div className="row d-flex align-items-center">

                            {/* VIDEO LINK */}
                            <div className="col-lg-6">
                                <div className="video-preview mb-40 text-center wow fadeInUp" data-wow-delay="0.6s" style={{visibility: "visible", animationDelay: "0.6s", animationName: "fadeInUp"}}>



                                    {/* Preview */}
                                    <img className="img-fluid" src="assets/images/mgcc.jpg" alt="video-photo" />


                                </div>
                            </div>	{/* END VIDEO LINK */}

                            {/* VIDEO TEXT */}
                            <div className="col-lg-6">
                                <div className="txt-block pc-30 mb-40 wow fadeInUp" data-wow-delay="0.4s" style={{visibility: "visible", animationDelay: "0.4s", animationName: "fadeInUp"}}>

                                    {/* Section ID */}
                                    <span className="section-id blue-color">Modern Currency</span>

                                    {/* Title */}
                                    <h3 className="h3-md steelblue-color">What is MGCC coin?</h3>

                                    {/* CONTENT BOX #1 */}
                                    <div className="box-list">
                                        <div className="box-list-icon"><i className="fa fa-angle-double-right"></i></div>
                                        <p>MGCC is a digital currency issued on 2020-08-08 based on the Ethereum ERC20 standard. The total supply is 420,000,000. The block height at the time of issuance:10617926. The smallest support unit after the decimal point is 6.
                                        </p>
                                        <a href="#" className="btn btn-blue blue-hover">Know More</a>
                                    </div>



                                </div>
                            </div>



                        </div>	    {/* End row */}
                    </div>	    {/* End container */}
                </section>







                {/* FOOTER-3
    ============================================= */}
                {/* END FOOTER-3 */}


                {/* The Modal */}

            </div>



        </>
    )
}
