<div class="top-header">
				<div class="container">
					<div class="row">
						<div class="col-6">
							<div class="header-address">
								<p><i class="fa fa-map-marker" aria-hidden="true"></i> G-130, sector-63, Noida </p>
								<a href=""><i class="fa fa-phone"></i> +91 1234567811</a>
							</div>
						</div>
						<div class="col-6">
							<div class="header-social">
								<a href="" class="btn btn-md btn-tra-white blue-hover ml-auto" title="Registration For Doctor" data-toggle="modal" data-target="#myModal">Registration</a>
								
									
								<a href="Profile.php" class="user-icon"><i class="fa fa-user-circle"></i> Atul</a>
								
							</div>
						</div>
					</div>
				</div>
			</div>

			<header>
				<div class="container">
					<nav class="navbar navbar-expand-md">
						<!-- Brand -->
						<a class="navbar-brand" href="index.php"><img src="assets/images/logo.png" alt=""></a>
					  
						<!-- Toggler/collapsibe Button -->
						<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
						  <span class="navbar-toggler-icon"><i class="fa fa-bars"></i></span>
						</button>
					  
						<!-- Navbar links -->
						<div class="collapse navbar-collapse" id="collapsibleNavbar">
							<ul class="navbar-nav ml-auto">
								<li class="nav-item">
								  <a class="nav-link" href="index.php">Home</a>
								</li>
								<li class="nav-item">
								  <a class="nav-link" href="about-us.php">About Us</a>
								</li>
								<li class="nav-item">
								  <a class="nav-link" href="product.php">Product & services</a>
								</li>
								<li class="nav-item dropdown">
									<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
									  Platforms
									</a>
									<div class="dropdown-menu">
									  <a class="dropdown-item" href="appointment.php">Telemedicine: Talk to an expert</a>
									  <a class="dropdown-item" href="nft.php">NFT market place</a>
									  <a class="dropdown-item" href="mgcc.php">MGCC Economics</a>
									</div>
								  </li>
								  <li class="nav-item">
									<a class="nav-link" href="ai.php">AI & Data</a>
								  </li>
								  <li class="nav-item">
									<a class="nav-link" href="contact.php">Contact Us</a>
								  </li>
							  </ul>
						</div>
					  </nav>
				</div>
			</header>