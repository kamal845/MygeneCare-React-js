
import React from 'react';
import { Link } from 'react-router-dom'
export default function Nft() {
    return (
        <>
            
            <div id="page" class="page">




{/* HEADER
    ============================================= */}
{/* END HEADER */}




{/* BREADCRUMB
    ============================================= */}
<div id="breadcrumb" class="division">
    <div class="container">
        <div class="row">
            <div class="col">
                <div class=" breadcrumb-holder">

                    {/* Breadcrumb Nav */}
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">NFT Marketplace</li>
                        </ol>
                    </nav>

                    {/* Title */}
                    <h4 class="h4-sm steelblue-color">NFT Marketplace</h4>

                </div>
            </div>
        </div> {/* End row */}
    </div> {/* End container */}
</div> {/* END BREADCRUMB */}




{/* APPOINTMENT PAGE
    ============================================= */}
<div class="wide-60">
    <div class="container">
        <div class="row">

            <div class="col-lg-10 offset-lg-1 section-title">

                {/* Title 	*/}
                <h3 class="h3-md steelblue-color">NFT Marketplace</h3>

                {/* Text */}
                <p>Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis libero at tempus,
                    blandit posuere ligula varius congue cursus porta feugiat
                </p>

            </div>

            <div class="col-lg-8 offset-lg-2">
                <div class="txt-block pr-30">

                    {/* Title */}
                   <h3 class="h3-md steelblue-color">NFT Marketplace</h3>

                   {/* Text */}
                   <p>Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor tempus feugiat
                      dolor lacinia.</p>

                   {/* APPOINTMENT FORM */}
                   <div id="appointment-form-holder" class="text-center">
                       <form name="appointmentform" class="row appointment-form">

                           {/* Form Select */}
                           <div id="input-department" class="col-md-12 input-department">
                               <select id="inlineFormCustomSelect1" name="department" class="custom-select department" required>
                                   <option value="">Select Department</option>  
                                     <option>Pediatrics Department</option>
                                     <option>Neurology Department</option>
                                     <option>Haematology Department</option>
                                     <option>X-Ray Diagnostic Department</option>
                                     <option>Cardiology Department</option>
                                     <option>MRI Department</option>
                                     <option>Laboratory Services</option>
                                     <option>Other</option>
                               </select>
                           </div>

                           {/* Form Select */}
                           <div id="input-doctor" class="col-md-12 input-doctor">
                               <select id="inlineFormCustomSelect2" name="doctor" class="custom-select doctor" required>
                                   <option value="">Select Doctor</option>  
                                     <option>Jonathan Barnes D.M.</option>
                                     <option>Hannah Harper D.M.</option>
                                     <option>Matthew Anderson D.M.</option>
                                     <option>Megan Coleman D.M.</option>
                                     <option>Joshua Elledge D.M.</option>
                                     <option>Other</option>
                               </select>
                           </div>

                            {/* Form Select */}
                           <div id="input-patient" class="col-md-12 input-patient">
                               <select id="inlineFormCustomSelect3" name="patient" class="custom-select patient" required>
                                   <option value="">Have You Visited Us Before?*</option>
                                   <option>New Patient</option>
                                   <option>Returning Patient</option>
                                   <option>Other</option>
                               </select>
                           </div>

                           {/* Contact Form Input */}
                           <div id="input-date" class="col-lg-12">
                               <input id="datetimepicker" type="text" name="date" class="form-control date" placeholder="Appointment Date" required /> 
                           </div>
                                               
                           {/* Contact Form Input */}
                           <div id="input-name" class="col-lg-12">
                               <input type="text" name="name" class="form-control name" placeholder="Enter Your Name*" required /> 
                           </div>
                                   
                           <div id="input-email" class="col-lg-12">
                               <input type="text" name="email" class="form-control email" placeholder="Enter Your Email*" required /> 
                           </div>

                           <div id="input-phone" class="col-lg-12">
                               <input type="tel" name="phone" class="form-control phone" placeholder="Enter Your Phone Number*" required /> 
                           </div>						                          
                                   
                           <div id="input-message" class="col-lg-12 input-message">
                               <textarea class="form-control message" name="message" rows="6" placeholder="Your Message ..."></textarea>
                           </div> 
                                                       
                           {/* Contact Form Button */}
                           <div class="col-lg-12 form-btn">  
                               <button type="submit" class="btn btn-blue blue-hover submit">Request an Appointment</button> 
                           </div>
                                                                         
                           {/* Contact Form Message */}
                           <div class="col-lg-12 appointment-form-msg text-center">
                               <div class="sending-msg"><span class="loading"></span></div>
                           </div>  
                                                     
                       </form> 

                   </div>	{/* END APPOINTMENT FORM */}

                   {/* Text */}
                   <p class="p-sm grey-color mb-30">* Porta semper lacus cursus, feugiat primis ultrice in ligula risus
                      auctor tempus feugiat dolor lacinia cubilia curae integer congue leo metus, primis in orci 
                      integer metus mollis faucibus enim. Nemo ipsam egestas volute turpis dolores ut aliquam quaerat
                      sodales sapien undo pretium purus
                   </p>
                   
                    
                </div>
            </div>





        </div> {/* End row */}
    </div> {/* End container */}
</div> {/* END APPOINTMENT PAGE */}




{/* FOOTER-3
    ============================================= */}
{/* END FOOTER-3 */}


{/* The Modal */}

</div>
  
        </>
    )
}

