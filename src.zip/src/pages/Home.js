
import React from 'react';
import OwlCarousel from 'react-owl-carousel';
import { Link } from 'react-router-dom'
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';

function Test() {
    return (
        <>
            <OwlCarousel className='owl-theme' autoplay loop margin={10} items={1}>
                <div class='item'>
                    <h4>1</h4>
                </div>
                <div class='item'>
                    <h4>2</h4>
                </div>
                <div class='item'>
                    <h4>3</h4>
                </div>
                <div class='item'>
                    <h4>4</h4>
                </div>
                <div class='item'>
                    <h4>5</h4>
                </div>
                <div class='item'>
                    <h4>6</h4>
                </div>
                <div class='item'>
                    <h4>7</h4>
                </div>
                <div class='item'>
                    <h4>8</h4>
                </div>
                <div class='item'>
                    <h4>9</h4>
                </div>
                <div class='item'>
                    <h4>10</h4>
                </div>
                <div class='item'>
                    <h4>11</h4>
                </div>
                <div class='item'>
                    <h4>12</h4>
                </div>
            </OwlCarousel>
        </>
    )
}

export default function Home() {

    return (
        <>

         
            <div id="page" class="page">
                {/* HERO-6
============================================= */}
                <section id="hero-6" class="division">

                
                    {/* SLIDER */}
                    <div class="slider1">
                        <ul class="slides">

                            <OwlCarousel className='owl-theme banner-slide' loop margin={10} autoplay items={1}>
                                {/* SLIDE #1 */}
                                <div className="item">
                                    <li id="slide-1">

                                       

                                        {/* Image Caption */}
                                        <div class="caption d-flex align-items-center center-align">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="caption-txt white-color">

                                                            {/* Title */}
                                                            <h5>Welcome to MedService</h5>
                                                            <h2>Your Personalized Genomics for Healthcare and Wellness</h2>



                                                            {/* Button */}
                                                            <a href="appointment.php" class="btn btn-blue tra-white-hover">Book An Appointment</a>

                                                        </div>
                                                    </div>
                                                </div>  {/* End row */}
                                            </div>  {/* End container */}
                                        </div>	{/* End Image Caption */}

                                    </li>	{/* END SLIDE #1 */}
                                </div>

                                <div className="item item-bg1">
                                    {/* SLIDE #2 */}
                                    <li id="slide-2">


                                        {/* Image Caption */}
                                        <div class="caption d-flex align-items-center center-align">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="caption-txt white-color">

                                                            {/* Title */}
                                                            <h5>Our clinic Provide</h5>
                                                            <h2>Complete Genomic Scan-Whole Genome Sequencing, Whole Exome Sequencing, Genotyping</h2>



                                                            {/* Button */}
                                                            <a href="appointment.php" class="btn btn-blue tra-white-hover">Book An Appointment</a>

                                                        </div>
                                                    </div>
                                                </div>  {/* End row */}
                                            </div>  {/* End container */}
                                        </div>	{/* End Image Caption */}

                                    </li>	{/* END SLIDE #2 */}
                                </div>

                                <div className="item item-bg2">
                                    {/* SLIDE #3 */}
                                    <li id="slide-3">


                                        {/* Image Caption */}
                                        <div class="caption d-flex align-items-center center-align">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="caption-txt white-color">

                                                            {/* Title */}
                                                            <h5>Our Medical Staff</h5>
                                                            <h2>Data Integrity and Security</h2>


                                                            {/* Button */}
                                                            <a href="appointment.php" class="btn btn-blue tra-white-hover">Book An Appointment</a>

                                                        </div>
                                                    </div>
                                                </div>  {/* End row */}
                                            </div>  {/* End container */}
                                        </div>	{/* End Image Caption */}

                                    </li>

                                </div>

                                <div className="item item-bg3">

                                    {/* SLIDE #3 */}
                                    <li id="slide-4">


                                        {/* Image Caption */}
                                        <div class="caption d-flex align-items-center center-align">
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="caption-txt white-color">

                                                            {/* Title */}
                                                            <h5>Our Medical Staff</h5>
                                                            <h2>New Age Healthcare and Wellness Economics- MGCC Digital Currency and NFT’s</h2>



                                                            {/* Button */}
                                                            <a href="appointment.php" class="btn btn-blue tra-white-hover">Book An Appointment</a>

                                                        </div>
                                                    </div>
                                                </div>  {/* End row */}
                                            </div>  {/* End container */}
                                        </div>	{/* End Image Caption */}

                                    </li>
                                    {/* END SLIDE #3 */}
                                </div>
                            </OwlCarousel>

                        </ul>
                    </div>	{/* END SLIDER */}


                </section>	{/* END HERO-6 */}





                {/* SERVICES-1
============================================= */}
                <section id="services-1" class="wide-50 services-section division">
                    <div class="container">
                        <div class="row">


                            {/* SERVICE BOX #1 */}
                            <div class="col-sm-6 col-lg-3">
                                <div class="sbox-1 icon-md wow fadeInUp" data-wow-delay="0.4s">

                                    {/* Icon */}
                                    <span class="flaticon-137-doctor blue-color"></span>

                                    {/* Title */}
                                    <h5 class="h5-sm steelblue-color">Qualified Doctors</h5>

                                    {/* Text */}
                                    <p>Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor
                                        tempus feugiat dolor lacinia
                                    </p>

                                </div>
                            </div>


                            {/* SERVICE BOX #2 */}
                            <div class="col-sm-6 col-lg-3">
                                <div class="sbox-1 icon-md wow fadeInUp" data-wow-delay="0.6s">

                                    {/* Icon */}
                                    <span class="flaticon-076-microscope blue-color"></span>

                                    {/* Title */}
                                    <h5 class="h5-sm steelblue-color">Modern Equipment</h5>

                                    {/* Text */}
                                    <p>Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor
                                        tempus feugiat dolor lacinia
                                    </p>

                                </div>
                            </div>


                            {/* SERVICE BOX #3 */}
                            <div class="col-sm-6 col-lg-3">
                                <div class="sbox-1 icon-md wow fadeInUp" data-wow-delay="0.8s">

                                    {/* Icon */}
                                    <span class="flaticon-008-ambulance-6 blue-color"></span>

                                    {/* Title */}
                                    <h5 class="h5-sm steelblue-color">Emergency Help</h5>

                                    {/* Text */}
                                    <p>Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor
                                        tempus feugiat dolor lacinia
                                    </p>

                                </div>
                            </div>


                            {/* SERVICE BOX #4 */}
                            <div class="col-sm-6 col-lg-3">
                                <div class="sbox-1 icon-md wow fadeInUp" data-wow-delay="1s">

                                    {/* Icon */}
                                    <span class="flaticon-083-stethoscope blue-color"></span>

                                    {/* Title */}
                                    <h5 class="h5-sm steelblue-color">Individual Approach</h5>

                                    {/* Text */}
                                    <p>Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor
                                        tempus feugiat dolor lacinia
                                    </p>

                                </div>
                            </div>


                        </div>	   {/* End row */}
                    </div>	   {/* End container */}
                </section>	{/* END SERVICES-1 */}




                {/* SERVICES-5
============================================= */}
                <section id="services-5" class="bg-lightgrey wide-100 services-section division">
                    <div class="container">


                        {/* SECTION TITLE */}
                        <div class="row">
                            <div class="col-lg-10 offset-lg-1 section-title">

                                {/* Title 	*/}
                                <h3 class="h3-md steelblue-color">Our Products</h3>

                                {/* Text */}
                                <p>Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis libero at tempus,
                                    blandit posuere ligula varius congue cursus porta feugiat
                                </p>

                            </div>
                        
                        </div>

                      

                        {/* SERVICES CONTENT */}
                        <div class="row">
                            <div class="col-md-12">
                                <div class="services-holder product-slide">


                                <OwlCarousel className='owl-theme' loop margin={10}
                                {...{
                                    items: 3,
                                    loop:true,
                                    autoplay:true,
                                    navBy: 1,
                                    autoplayTimeout: 4500,
                                    autoplayHoverPause: false,
                                    smartSpeed: 1500,
                                    responsive:{
                                        0:{
                                            items:1
                                        },
                                        767:{
                                            items:1
                                        },
                                        768:{
                                            items:2
                                        },
                                        991:{
                                            items:2
                                        },
                                        1000:{
                                            items:4
                                        }
                                    }
                            }}
                                >


                                    <div class="sbox-5 product-card">

                                        {/* Image */}
                                        <img class="img-fluid" src="assets/images/prod.png" alt="content-image" />

                                        {/* Text */}
                                        <div class="sbox-5-txt">


                                            {/* Title */}
                                            <h5 class="h5-sm blue-color">Whole Genome Sequencing</h5>
                                            <span><i class="fa fa-inr"> 7999/-</i>&nbsp;&nbsp;&nbsp;&nbsp; or &nbsp;&nbsp;&nbsp;&nbsp;</span>
                                            <i class="fa fa-btc" aria-hidden="true"> 18</i>

                                            {/* Text */}
                                            <p>Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor
                                                tempus feugiat dolor lacinia cubilia curae integer congue leo metus
                                            </p>
                                            <button class="btn btn-blue blue-hover mt-20">Buy Now</button>

                                        </div>

                                    </div>


                                    {/* SERVICE BOX #2 */}
                                    <div class="sbox-5 product-card">

                                        {/* Image */}
                                        <img class="img-fluid" src="assets/images/prod.png" alt="content-image" />

                                        {/* Text */}
                                        <div class="sbox-5-txt">


                                            {/* Title */}
                                            <h5 class="h5-sm blue-color">Whole Genome Sequencing</h5>
                                            <span><i class="fa fa-inr"> 7999/-</i>&nbsp;&nbsp;&nbsp;&nbsp; or &nbsp;&nbsp;&nbsp;&nbsp;</span>
                                            <i class="fa fa-btc" aria-hidden="true"> 18</i>

                                            {/* Text */}
                                            <p>Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor
                                                tempus feugiat dolor lacinia cubilia curae integer congue leo metus
                                            </p>
                                            <button class="btn btn-blue blue-hover mt-20">Buy Now</button>

                                        </div>

                                    </div>


                                    {/* SERVICE BOX #3 */}
                                    <div class="sbox-5 product-card">

                                        {/* Image */}
                                        <img class="img-fluid" src="assets/images/prod.png" alt="content-image" />

                                        {/* Text */}
                                        <div class="sbox-5-txt">


                                            {/* Title */}
                                            <h5 class="h5-sm blue-color">Whole Genome Sequencing</h5>
                                            <span><i class="fa fa-inr"> 7999/-</i>&nbsp;&nbsp;&nbsp;&nbsp; or &nbsp;&nbsp;&nbsp;&nbsp;</span>
                                            <i class="fa fa-btc" aria-hidden="true"> 18</i>

                                            {/* Text */}
                                            <p>Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor
                                                tempus feugiat dolor lacinia cubilia curae integer congue leo metus
                                            </p>
                                            <button class="btn btn-blue blue-hover mt-20">Buy Now</button>

                                        </div>

                                    </div>


                                    {/* SERVICE BOX #4 */}
                                    <div class="sbox-5 product-card">

                                        {/* Image */}
                                        <img class="img-fluid" src="assets/images/prod.png" alt="content-image" />

                                        {/* Text */}
                                        <div class="sbox-5-txt">


                                            {/* Title */}
                                            <h5 class="h5-sm blue-color">Whole Genome Sequencing</h5>
                                            <span><i class="fa fa-inr"> 7999/-</i>&nbsp;&nbsp;&nbsp;&nbsp; or &nbsp;&nbsp;&nbsp;&nbsp;</span>
                                            <i class="fa fa-btc" aria-hidden="true"> 18</i>

                                            {/* Text */}
                                            <p>Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor
                                                tempus feugiat dolor lacinia cubilia curae integer congue leo metus
                                            </p>
                                            <button class="btn btn-blue blue-hover mt-20">Buy Now</button>

                                        </div>

                                    </div>


                                    {/* SERVICE BOX #5 */}
                                    <div class="sbox-5 product-card">

                                        {/* Image */}
                                        <img class="img-fluid" src="assets/images/prod.png" alt="content-image" />

                                        {/* Text */}
                                        <div class="sbox-5-txt">


                                            {/* Title */}
                                            <h5 class="h5-sm blue-color">Whole Genome Sequencing</h5>
                                            <span><i class="fa fa-inr"> 7999/-</i>&nbsp;&nbsp;&nbsp;&nbsp; or &nbsp;&nbsp;&nbsp;&nbsp;</span>
                                            <i class="fa fa-btc" aria-hidden="true"> 18</i>

                                            {/* Text */}
                                            <p>Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor
                                                tempus feugiat dolor lacinia cubilia curae integer congue leo metus
                                            </p>
                                            <button class="btn btn-blue blue-hover mt-20">Buy Now</button>

                                        </div>

                                    </div>
                                    </OwlCarousel>





                                </div>
                            </div>
                        </div>	{/* END SERVICES CONTENT */}


                    </div>	   {/* End container */}
                </section>	 {/* END SERVICES-5 */}


                {/* APPOINTMENT PAGE
============================================= */}
                <div id="appointment-page appointment-form" class="wide-60 appointment-page-section division">
                    <div class="container">
                        <div class="row">


                            {/* SERVICE DETAILS */}
                            <div class="col-lg-8">
                                <div class="txt-block pr-30">

                                    {/* Title */}
                                    <h3 class="h3-md steelblue-color">Book an Appointment</h3>

                                    {/* Text */}
                                    <p>Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor tempus feugiat
                                        dolor lacinia cubilia curae integer congue leo metus, primis in orci integer metus.
                                    </p>

                                    {/* APPOINTMENT FORM */}
                                    <div id="appointment-form-holder" class="text-center">
                                        <form name="appointmentform" class="row appointment-form">

                                            {/* Form Select */}
                                            <div id="input-department" class="col-md-12 input-department">
                                                <select id="inlineFormCustomSelect1" name="department" class="custom-select department" required>
                                                    <option value="">Select Department</option>
                                                    <option>Whole Genome Sequencing</option>
                                                    <option>Whole Exome Sequencing</option>
                                                    <option>Genotyping</option>
                                                    <option>Pharmacogenomics</option>
                                                    <option>Egg or Sperm Selection</option>
                                                </select>
                                            </div>

                                            {/* Form Select */}
                                            <div id="input-doctor" class="col-md-12 input-doctor">
                                                <select id="inlineFormCustomSelect2" name="doctor" class="custom-select doctor" required>
                                                    <option value="">Select Doctor</option>
                                                    <option>Jonathan Barnes D.M.</option>
                                                    <option>Hannah Harper D.M.</option>
                                                    <option>Matthew Anderson D.M.</option>
                                                    <option>Megan Coleman D.M.</option>
                                                    <option>Joshua Elledge D.M.</option>
                                                    <option>Other</option>
                                                </select>
                                            </div>

                                            {/* Form Select */}
                                            <div id="input-patient" class="col-md-12 input-patient">
                                                <select id="inlineFormCustomSelect3" name="patient" class="custom-select patient" required>
                                                    <option value="">Have You Visited Us Before?*</option>
                                                    <option>New Patient</option>
                                                    <option>Returning Patient</option>
                                                    <option>Other</option>
                                                </select>
                                            </div>

                                            {/* Contact Form Input */}
                                            <div id="input-date" class="col-lg-12">
                                                <input id="datetimepicker" type="text" name="date" class="form-control date" placeholder="Appointment Date" required />
                                            </div>

                                            {/* Contact Form Input */}
                                            <div id="input-name" class="col-lg-12">
                                                <input type="text" name="name" class="form-control name" placeholder="Enter Your Name*" required />
                                            </div>

                                            <div id="input-email" class="col-lg-12">
                                                <input type="text" name="email" class="form-control email" placeholder="Enter Your Email*" required />
                                            </div>

                                            <div id="input-phone" class="col-lg-12">
                                                <input type="tel" name="phone" class="form-control phone" placeholder="Enter Your Phone Number*" required />
                                            </div>

                                            <div id="input-message" class="col-lg-12 input-message">
                                                <textarea class="form-control message" name="message" rows="2" placeholder="Your Message ..."></textarea>
                                            </div>

                                            {/* Contact Form Button */}
                                            <div class="col-lg-12 form-btn">
                                                <button type="submit" class="btn btn-blue blue-hover submit">Request an Appointment</button>
                                            </div>

                                            {/* Contact Form Message */}
                                            <div class="col-lg-12 appointment-form-msg text-center">
                                                <div class="sending-msg"><span class="loading"></span></div>
                                            </div>

                                        </form>

                                    </div>	{/* END APPOINTMENT FORM */}


                                </div>
                            </div>	{/* END SERVICE DETAILS */}


                            {/* SIDEBAR */}
                            <aside id="sidebar" class="col-lg-4">



                                {/* SIDEBAR TABLE */}
                                <div class="sidebar-table blue-table sidebar-div mb-50">

                                    {/* Title */}
                                    <h5 class="h5-md">Working Time</h5>

                                    {/* Text */}
                                    <p class="p-sm">Porta semper lacus cursus, feugiat primis ultrice ligula risus auctor at
                                        tempus feugiat dolor lacinia cursus nulla vitae massa
                                    </p>

                                    {/* Table */}
                                    <table class="table">
                                        <tbody>
                                            <tr>
                                                <td>Mon – Wed</td>
                                                <td> - </td>
                                                <td class="text-right">9:00 AM - 7:00 PM</td>
                                            </tr>
                                            <tr>
                                                <td>Thursday</td>
                                                <td> - </td>
                                                <td class="text-right">9:00 AM - 6:30 PM</td>
                                            </tr>
                                            <tr>
                                                <td>Friday</td>
                                                <td> - </td>
                                                <td class="text-right">9:00 AM - 6:00 PM</td>
                                            </tr>
                                            <tr class="last-tr">
                                                <td>Sun - Sun</td>
                                                <td>-</td>
                                                <td class="text-right">CLOSED</td>
                                            </tr>
                                        </tbody>
                                    </table>

                                    {/* Title */}
                                    <h5 class="h5-xs">Need a personal health plan?</h5>

                                    {/* Text */}
                                    <p class="p-sm">Porta semper lacus cursus, and feugiat primis ultrice ligula at risus auctor</p>

                                </div>	{/* END SIDEBAR TABLE */}


                            </aside>   {/* END SIDEBAR */}


                        </div>	{/* End row */}
                    </div>	 {/* End container */}
                </div>	{/* END APPOINTMENT PAGE */}


                {/* TABS-1
============================================= */}
                <section id="tabs-1" class="pb-100 tabs-section division">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-10 offset-lg-1 section-title">

                                {/* Title 	*/}
                                <h3 class="h3-md steelblue-color">Our Services</h3>

                                {/* Text */}
                                <p>Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis libero at tempus,
                                    blandit posuere ligula varius congue cursus porta feugiat
                                </p>

                            </div>
                            <div class="col-md-12">


                                {/* TABS NAVIGATION */}
                                <div id="tabs-nav" class="list-group text-center">
                                    <ul class="nav nav-pills" id="pills-tab" role="tablist">

                                        {/* TAB-1 LINK */}
                                        <li class="nav-item icon-xs">
                                            <a class="nav-link active" id="tab1-list" data-toggle="pill" href="#tab-1" role="tab" aria-controls="tab-1" aria-selected="true">
                                                <span class="flaticon-083-stethoscope"></span> whole Genome Sequencing
                                            </a>
                                        </li>

                                        {/* TAB-2 LINK */}
                                        <li class="nav-item icon-xs">
                                            <a class="nav-link" id="tab2-list" data-toggle="pill" href="#tab-2" role="tab" aria-controls="tab-2" aria-selected="false">
                                                <span class="flaticon-005-blood-donation-3"></span> whole Exome Sequencing
                                            </a>
                                        </li>

                                        {/* TAB-3 LINK */}
                                        <li class="nav-item icon-xs">
                                            <a class="nav-link" id="tab3-list" data-toggle="pill" href="#tab-3" role="tab" aria-controls="tab-3" aria-selected="false">
                                                <span class="flaticon-031-scanner"></span> Genotyping
                                            </a>
                                        </li>

                                        {/* TAB-4 LINK */}
                                        <li class="nav-item icon-xs">
                                            <a class="nav-link" id="tab4-list" data-toggle="pill" href="#tab-4" role="tab" aria-controls="tab-4" aria-selected="false">
                                                <span class="flaticon-048-lungs"></span> Pharmacogenomics
                                            </a>
                                        </li>

                                        {/* TAB-5 LINK */}
                                        <li class="nav-item icon-xs">
                                            <a class="nav-link" id="tab5-list" data-toggle="pill" href="#tab-5" role="tab" aria-controls="tab-4" aria-selected="false">
                                                <span class="flaticon-048-lungs"></span> Egg or Sperm Selection
                                            </a>
                                        </li>

                                    </ul>

                                </div>	{/* END TABS NAVIGATION */}


                                {/* TABS CONTENT */}
                                <div class="tab-content" id="pills-tabContent">


                                    {/* TAB-1 CONTENT */}
                                    <div class="tab-pane fade show active" id="tab-1" role="tabpanel" aria-labelledby="tab1-list">
                                        <div class="row d-flex align-items-center">


                                            {/* TAB-1 IMAGE */}
                                            <div class="col-lg-6">
                                                <div class="tab-img">
                                                    <img class="img-fluid" src="assets/images/pediatrics_700x700.jpg" alt="tab-image" />
                                                </div>
                                            </div>


                                            {/* TAB-1 TEXT */}
                                            <div class="col-lg-6">
                                                <div class="txt-block pc-30">

                                                    {/* Title */}
                                                    <h3 class="h3-md steelblue-color">What is whole genome sequencing?</h3>

                                                    {/* Text */}
                                                    <p class="mb-30">The genome, or genetic material, of an organism (bacteria, virus, potato, human) is made up of DNA. Each organism has a unique DNA sequence which is composed of bases (A, T, C, and G). If you know the sequence of the bases in an organism, you have identified its unique DNA fingerprint, or pattern. Determining the order of bases is called sequencing. Whole genome sequencing is a laboratory procedure that determines the order of bases in the genome of an organism in one process.
                                                    </p>



                                                    {/* Button */}
                                                    <a href="service-1.html" class="btn btn-blue blue-hover mt-30">View More Details</a>

                                                </div>
                                            </div>	{/* END TAB-1 TEXT */}


                                        </div>
                                    </div>	{/* END TAB-1 CONTENT */}


                                    {/* TAB-2 CONTENT */}
                                    <div class="tab-pane fade" id="tab-2" role="tabpanel" aria-labelledby="tab2-list">
                                        <div class="row d-flex align-items-center">


                                            {/* TAB-2 IMAGE */}
                                            <div class="col-lg-6">
                                                <div class="tab-imgs">
                                                    <img class="img-fluid" src="assets/images/hematology_700x700.jpg" alt="tab-image" />
                                                </div>
                                            </div>


                                            {/* TAB-2 TEXT */}
                                            <div class="col-lg-6">
                                                <div class="txt-block pc-30">

                                                    {/* Title */}
                                                    <h3 class="h3-md steelblue-color">What is Exome Sequencing?</h3>

                                                    {/* Text */}
                                                    <p class="mb-30">Whole-exome sequencing is a widely used next-generation sequencing (NGS) method that involves sequencing the protein-coding regions of the genome. The human exome represents less than 2% of the genome, but contains ~85% of known disease-related variants,1 making this method a cost-effective alternative to whole-genome sequencing.

                                                        Exome sequencing using exome enrichment can efficiently identify coding variants across a broad range of applications, including population genetics, genetic disease, and cancer studies.
                                                    </p>


                                                    {/* Button */}
                                                    <a href="service-2.html" class="btn btn-blue blue-hover mt-30">View More Details</a>

                                                </div>
                                            </div>	{/* END TAB-2 TEXT */}


                                        </div>
                                    </div>	{/* END TAB-2 CONTENT */}


                                    {/* TAB-3 CONTENT */}
                                    <div class="tab-pane fade" id="tab-3" role="tabpanel" aria-labelledby="tab3-list">
                                        <div class="row d-flex align-items-center">


                                            {/* TAB-3 IMAGE */}
                                            <div class="col-lg-6">
                                                <div class="tab-img">
                                                    <img class="img-fluid" src="assets/images/mri_700x700.jpg" alt="tab-image" />
                                                </div>
                                            </div>


                                            {/* TAB-3 TEXT */}
                                            <div class="col-lg-6">
                                                <div class="txt-block pc-30">

                                                    {/* Title */}
                                                    <h3 class="h3-md steelblue-color">Genotyping</h3>

                                                    {/* Text */}
                                                    <p class="mb-30">Whole-exome sequencing is a widely used next-generation sequencing (NGS) method that involves sequencing the protein-coding regions of the genome. The human exome represents less than 2% of the genome, but contains ~85% of known disease-related variants,1 making this method a cost-effective alternative to whole-genome sequencing.

                                                        Exome sequencing using exome enrichment can efficiently identify coding variants across a broad range of applications, including population genetics, genetic disease, and cancer studies.
                                                    </p>


                                                    {/* Button */}
                                                    <a href="service-1.html" class="btn btn-blue blue-hover mt-30">View More Details</a>

                                                </div>
                                            </div>	{/* END TAB-3 TEXT */}


                                        </div>
                                    </div>	{/* END TAB-3 CONTENT */}


                                    {/* TAB-4 CONTENT */}
                                    <div class="tab-pane fade" id="tab-4" role="tabpanel" aria-labelledby="tab4-list">
                                        <div class="row d-flex align-items-center">


                                            {/* TAB-4 IMAGE */}
                                            <div class="col-lg-6">
                                                <div class="tab-img">
                                                    <img class="img-fluid" src="assets/images/x-ray_700x700.jpg" alt="tab-image" />
                                                </div>
                                            </div>


                                            {/* TAB-4 TEXT */}
                                            <div class="col-lg-6">
                                                <div class="txt-block pc-30">

                                                    {/* Title */}
                                                    <h3 class="h3-md steelblue-color">Pharmacogenomics</h3>

                                                    {/* Text */}
                                                    <p class="mb-30">Whole-exome sequencing is a widely used next-generation sequencing (NGS) method that involves sequencing the protein-coding regions of the genome. The human exome represents less than 2% of the genome, but contains ~85% of known disease-related variants,1 making this method a cost-effective alternative to whole-genome sequencing.

                                                        Exome sequencing using exome enrichment can efficiently identify coding variants across a broad range of applications, including population genetics, genetic disease, and cancer studies.
                                                    </p>


                                                    {/* Button */}
                                                    <a href="service-2.html" class="btn btn-blue blue-hover mt-30">View More Details</a>

                                                </div>
                                            </div>	{/* END TAB-4 TEXT */}


                                        </div>
                                    </div>	{/* END TAB-4 CONTENT */}



                                    {/* TAB-5 CONTENT */}
                                    <div class="tab-pane fade" id="tab-5" role="tabpanel" aria-labelledby="tab5-list">
                                        <div class="row d-flex align-items-center">


                                            {/* TAB-4 IMAGE */}
                                            <div class="col-lg-6">
                                                <div class="tab-img">
                                                    <img class="img-fluid" src="assets/images/x-ray_700x700.jpg" alt="tab-image" />
                                                </div>
                                            </div>


                                            {/* TAB-4 TEXT */}
                                            <div class="col-lg-6">
                                                <div class="txt-block pc-30">

                                                    {/* Title */}
                                                    <h3 class="h3-md steelblue-color">Egg or Sperm Selection</h3>

                                                    {/* Text */}
                                                    <p class="mb-30">Whole-exome sequencing is a widely used next-generation sequencing (NGS) method that involves sequencing the protein-coding regions of the genome. The human exome represents less than 2% of the genome, but contains ~85% of known disease-related variants,1 making this method a cost-effective alternative to whole-genome sequencing.

                                                        Exome sequencing using exome enrichment can efficiently identify coding variants across a broad range of applications, including population genetics, genetic disease, and cancer studies.
                                                    </p>

                                                    {/* Options List */}
                                                    <div class="row">

                                                        <div class="col-xl-6">

                                                            {/* Option #1 */}
                                                            <div class="box-list">
                                                                <div class="box-list-icon blue-color"><i class="fa fa-angle-double-right"></i></div>
                                                                <p class="p-sm">Nemo ipsam egestas volute and turpis dolores quaerat</p>
                                                            </div>

                                                            {/* Option #2 */}
                                                            <div class="box-list">
                                                                <div class="box-list-icon blue-color"><i class="fa fa-angle-double-right"></i></div>
                                                                <p class="p-sm">Magna luctus tempor</p>
                                                            </div>


                                                        </div>

                                                        <div class="col-xl-6">

                                                            {/* Option #4 */}
                                                            <div class="box-list">
                                                                <div class="box-list-icon blue-color"><i class="fa fa-angle-double-right"></i></div>
                                                                <p class="p-sm">Magna luctus tempor blandit a vitae suscipit mollis</p>
                                                            </div>

                                                            {/* Option #5 */}
                                                            <div class="box-list">
                                                                <div class="box-list-icon blue-color"><i class="fa fa-angle-double-right"></i></div>
                                                                <p class="p-sm">Nemo ipsam egestas volute turpis dolores quaerat</p>
                                                            </div>


                                                        </div>

                                                    </div>	{/* End Options List */}

                                                    {/* Button */}
                                                    <a href="service-2.html" class="btn btn-blue blue-hover mt-30">View More Details</a>

                                                </div>
                                            </div>	{/* END TAB-4 TEXT */}


                                        </div>
                                    </div>	{/* END TAB-5 CONTENT */}


                                </div>	{/* END TABS CONTENT */}


                            </div>
                        </div>     {/* End row */}
                    </div>     {/* End container */}
                </section>	{/* END TABS-1 */}







                {/* INFO-2
============================================= */}
                <section id="info-2" class="info-section division">
                    <div class="container">
                        <div class="row d-flex align-items-center">


                            {/* TEXT BLOCK */}
                            <div class="col-lg-6">
                                <div class="txt-block pc-30 mb-40 wow fadeInUp" data-wow-delay="0.4s">

                                    {/* Section ID */}
                                    <span class="section-id blue-color">About Us</span>

                                    {/* Title */}
                                    <h3 class="h3-md steelblue-color">Complete Medical Solutions in One Place</h3>

                                    {/* Text */}
                                    <p class="mb-30">An enim nullam tempor sapien gravida donec enim ipsum blandit
                                        porta justo integer odio velna vitae auctor integer congue magna at pretium
                                        purus pretium ligula rutrum itae laoreet augue posuere and curae integer
                                        congue leo metus mollis primis and mauris
                                    </p>

                                    {/* Options List */}
                                    <div class="row">

                                        <div class="col-xl-6">

                                            {/* Option #1 */}
                                            <div class="box-list m-top-15">
                                                <div class="box-list-icon blue-color"><i class="fa fa-angle-double-right"></i></div>
                                                <p class="p-sm">Nemo ipsam egestas volute and turpis dolores quaerat</p>
                                            </div>

                                            {/* Option #2 */}
                                            <div class="box-list">
                                                <div class="box-list-icon blue-color"><i class="fa fa-angle-double-right"></i></div>
                                                <p class="p-sm">Magna luctus tempor</p>
                                            </div>



                                        </div>

                                        <div class="col-xl-6">

                                            {/* Option #4 */}
                                            <div class="box-list">
                                                <div class="box-list-icon blue-color"><i class="fa fa-angle-double-right"></i></div>
                                                <p class="p-sm">Magna luctus tempor blandit a vitae suscipit mollis</p>
                                            </div>

                                            {/* Option #5 */}
                                            <div class="box-list m-top-15">
                                                <div class="box-list-icon blue-color"><i class="fa fa-angle-double-right"></i></div>
                                                <p class="p-sm">Nemo ipsam egestas volute turpis dolores quaerat</p>
                                            </div>


                                        </div>


                                    </div>	{/* End Options List */}

                                    {/* Button */}
                                    <Link to="/about" class="btn btn-blue blue-hover mt-30">View More Details</Link>


                                </div>
                            </div>	{/* END TEXT BLOCK */}


                            {/* IMAGE BLOCK */}
                            <div class="col-lg-6">
                                <div class="info-2-img wow fadeInUp" data-wow-delay="0.6s">
                                    <img class="img-fluid" src="assets/images/about.jpg" alt="info-image" />
                                </div>
                            </div>


                        </div>    {/* End row */}
                    </div>	   {/* End container */}
                </section>	{/* END INFO-2 */}

                {/* DOCTORS-1
============================================= */}
                <section id="doctors-1" class="wide-40 doctors-section division">
                    <div class="container">


                        {/* SECTION TITLE */}
                        <div class="row">
                            <div class="col-lg-10 offset-lg-1 section-title">

                                {/* Title 	*/}
                                <h3 class="h3-md steelblue-color">Our Medical Specialists</h3>

                                {/* Text */}
                                <p>Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis libero at tempus,
                                    blandit posuere ligula varius congue cursus porta feugiat
                                </p>

                            </div>
                        </div>	 {/* END SECTION TITLE */}


                        <div class="row">


                            {/* DOCTOR #1 */}
                            <div class="col-md-6 col-lg-3">
                                <div class="doctor-1">

                                    {/* Doctor Photo */}
                                    <div class="hover-overlay text-center">

                                        {/* Photo */}
                                        <img class="img-fluid" src="assets/images/doctor-1.jpg" alt="doctor-foto" />
                                        <div class="item-overlay"></div>

                                        {/* Profile Link */}
                                        <div class="profile-link">
                                            <a class="btn btn-sm btn-tra-white black-hover" href="doctor-1.html" title="">View More Info</a>
                                        </div>

                                    </div>

                                    {/* Doctor Meta */}
                                    <div class="doctor-meta">

                                        <h5 class="h5-sm steelblue-color">Jonathan Barnes D.M.</h5>
                                        <span class="blue-color">Whole Genome Sequencing</span>

                                        <p class="p-sm grey-color">Donec vel sapien augue integer turpis cursus porta, mauris sed
                                            augue luctus magna dolor luctus ipsum neque
                                        </p>

                                    </div>

                                </div>
                            </div>	{/* END DOCTOR #1 */}


                            {/* DOCTOR #2 */}
                            <div class="col-md-6 col-lg-3">
                                <div class="doctor-1">

                                    {/* Doctor Photo */}
                                    <div class="hover-overlay text-center">

                                        {/* Photo */}
                                        <img class="img-fluid" src="assets/images/doctor-2.jpg" alt="doctor-foto" />
                                        <div class="item-overlay"></div>

                                        {/* Profile Link */}
                                        <div class="profile-link">
                                            <a class="btn btn-sm btn-tra-white black-hover" href="doctor-2.html" title="">View More Info</a>
                                        </div>

                                    </div>

                                    {/* Doctor Meta */}
                                    <div class="doctor-meta">

                                        <h5 class="h5-sm steelblue-color">Hannah Harper D.M.</h5>
                                        <span class="blue-color">Whole Exome Sequencing</span>

                                        <p class="p-sm grey-color">Donec vel sapien augue integer turpis cursus porta, mauris sed
                                            augue luctus magna dolor luctus ipsum neque
                                        </p>

                                    </div>

                                </div>
                            </div>	{/* END DOCTOR #2 */}


                            {/* DOCTOR #3 */}
                            <div class="col-md-6 col-lg-3">
                                <div class="doctor-1">

                                    {/* Doctor Photo */}
                                    <div class="hover-overlay text-center">

                                        {/* Photo */}
                                        <img class="img-fluid" src="assets/images/doctor-3.jpg" alt="doctor-foto" />
                                        <div class="item-overlay"></div>

                                        {/* Profile Link */}
                                        <div class="profile-link">
                                            <a class="btn btn-sm btn-tra-white black-hover" href="doctor-1.html" title="">View More Info</a>
                                        </div>

                                    </div>

                                    {/* Doctor Meta */}
                                    <div class="doctor-meta">

                                        <h5 class="h5-sm steelblue-color">Matthew Anderson D.M.</h5>
                                        <span class="blue-color">Genotyping	</span>

                                        <p class="p-sm grey-color">Donec vel sapien augue integer turpis cursus porta, mauris sed
                                            augue luctus magna dolor luctus ipsum neque
                                        </p>

                                    </div>

                                </div>
                            </div>	{/* END DOCTOR #3 */}


                            {/* DOCTOR #4 */}
                            <div class="col-md-6 col-lg-3">
                                <div class="doctor-1">

                                    {/* Doctor Photo */}
                                    <div class="hover-overlay text-center">

                                        {/* Photo */}
                                        <img class="img-fluid" src="assets/images/doctor-4.jpg" alt="doctor-foto" />
                                        <div class="item-overlay"></div>

                                        {/* Profile Link */}
                                        <div class="profile-link">
                                            <a class="btn btn-sm btn-tra-white black-hover" href="doctor-2.html" title="">View More Info</a>
                                        </div>

                                    </div>

                                    {/* Doctor Meta */}
                                    <div class="doctor-meta">

                                        <h5 class="h5-sm steelblue-color">Megan Coleman</h5>
                                        <span class="blue-color">Pharmacogenomics</span>

                                        <p class="p-sm grey-color">Donec vel sapien augue integer turpis cursus porta, mauris sed
                                            augue luctus magna dolor luctus ipsum neque
                                        </p>

                                    </div>

                                </div>
                            </div>	{/* END DOCTOR #4 */}


                        </div>	    {/* End row */}


                        {/* ALL DOCTORS BUTTON */}
                        <div class="row">
                            <div class="col-md-12 text-center">
                                <div class="all-doctors mb-40">
                                    <Link to="alldoctor" class="btn btn-blue blue-hover">Meet All Doctors</Link>
                                </div>
                            </div>
                        </div>


                    </div>	   {/* End container */}
                </section>	{/* END DOCTORS-1 */}


                {/* TESTIMONIALS-2
============================================= */}
                <section id="reviews-2" class="bg-lightgrey wide-100 reviews-section division">
                    <div class="container">


                        {/* SECTION TITLE */}
                        <div class="row">
                            <div class="col-lg-10 offset-lg-1 section-title">

                                {/* Title 	*/}
                                <h3 class="h3-md steelblue-color">What Our Patients Say</h3>

                                {/* Text */}
                                <p>Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis libero at tempus,
                                    blandit posuere ligula varius congue cursus porta feugiat
                                </p>

                            </div>
                        </div>	 {/* END SECTION TITLE */}


                        {/* TESTIMONIALS CONTENT */}
                        <div class="row">
                            <div class="col-md-12">
                                <div class="reviews-holder">

                                <OwlCarousel className='owl-theme' loop margin={10}
                                      {...{
                                        items: 3,
                                        loop:true,
                                        autoplay:true,
                                        navBy: 1,
                                        autoplayTimeout: 4500,
                                        autoplayHoverPause: false,
                                        smartSpeed: 1500,
                                        responsive:{
                                            0:{
                                                items:1
                                            },
                                            767:{
                                                items:1
                                            },
                                            768:{
                                                items:2
                                            },
                                            991:{
                                                items:2
                                            },
                                            1000:{
                                                items:4
                                            }
                                        }
                                }}
                                >

                                    {/* TESTIMONIAL #1 */}
                                    <div class="review-2">
                                        <div class="review-txt text-center">

                                            {/* Quote */}
                                            <div class="quote"><img src="assets/images/quote.png" alt="quote-img" /></div>

                                            {/* Author Avatar */}
                                            <div class="testimonial-avatar">
                                                <img src="assets/images/review-author-1.jpg" alt="testimonial-avatar" />
                                            </div>

                                            {/* Testimonial Text */}
                                            <p>Etiam sapien sem at sagittis congue an augue massa varius egestas a suscipit
                                                magna undo tempus aliquet porta vitae
                                            </p>

                                            {/* Testimonial Author */}
                                            <div class="review-author">
                                                <h5 class="h5-sm">Scott Boxer</h5>
                                                <span>Programmer</span>
                                            </div>

                                        </div>
                                    </div>	{/*END  TESTIMONIAL #1 */}


                                    {/* TESTIMONIAL #2 */}
                                    <div class="review-2">
                                        <div class="review-txt text-center">

                                            {/* Quote */}
                                            <div class="quote"><img src="assets/images/quote.png" alt="quote-img" /></div>

                                            {/* Author Avatar */}
                                            <div class="testimonial-avatar">
                                                <img src="assets/images/review-author-2.jpg" alt="testimonial-avatar" />
                                            </div>

                                            {/* Testimonial Text */}
                                            <p>Mauris donec ociis magnisa a sapien etiam sapien congue augue egestas et ultrice
                                                vitae purus diam integer congue magna ligula egestas
                                            </p>

                                            {/* Testimonial Author */}
                                            <div class="review-author">
                                                <h5 class="h5-sm">Penelopa Peterson</h5>
                                                <span>Project Manager</span>
                                            </div>

                                        </div>
                                    </div>	{/* END TESTIMONIAL #2 */}


                                    {/* TESTIMONIAL #3 */}
                                    <div class="review-2">
                                        <div class="review-txt text-center">

                                            {/* Quote */}
                                            <div class="quote"><img src="assets/images/quote.png" alt="quote-img" /></div>

                                            {/* Author Avatar */}
                                            <div class="testimonial-avatar">
                                                <img src="assets/images/review-author-3.jpg" alt="testimonial-avatar" />
                                            </div>

                                            {/* Testimonial Text */}
                                            <p>At sagittis congue augue an egestas magna ipsum vitae purus ipsum primis undo cubilia
                                                laoreet augue
                                            </p>

                                            {/* Testimonial Author */}
                                            <div class="review-author">
                                                <h5 class="h5-sm">M.Scanlon</h5>
                                                <span>Photographer</span>
                                            </div>

                                        </div>
                                    </div>	{/* END TESTIMONIAL #3 */}


                                    {/* TESTIMONIAL #4 */}
                                    <div class="review-2">
                                        <div class="review-txt text-center">

                                            {/* Quote */}
                                            <div class="quote"><img src="assets/images/quote.png" alt="quote-img" /></div>

                                            {/* Author Avatar */}
                                            <div class="testimonial-avatar">
                                                <img src="assets/images/review-author-4.jpg" alt="testimonial-avatar" />
                                            </div>

                                            {/* Testimonial Text */}
                                            <p>Mauris donec ociis magnis sapien etiam sapien congue augue pretium ligula
                                                a lectus aenean magna mauris
                                            </p>

                                            {/* Testimonial Author */}
                                            <div class="review-author">
                                                <h5 class="h5-sm">Jeremy Kruse</h5>
                                                <span>Graphic Designer</span>
                                            </div>

                                        </div>
                                    </div>	{/* END TESTIMONIAL #4 */}


                                    {/* TESTIMONIAL #5 */}
                                    <div class="review-2">
                                        <div class="review-txt text-center">

                                            {/* Quote */}
                                            <div class="quote"><img src="assets/images/quote.png" alt="quote-img" /></div>

                                            {/* Author Avatar */}
                                            <div class="testimonial-avatar">
                                                <img src="assets/images/review-author-5.jpg" alt="testimonial-avatar" />
                                            </div>

                                            {/* Testimonial Text */}
                                            <p>An augue in cubilia laoreet magna suscipit egestas magna ipsum at purus ipsum
                                                primis in augue ulta ligula egestas
                                            </p>

                                            {/* Testimonial Author */}
                                            <div class="review-author">
                                                <h5 class="h5-sm">Evelyn Martinez</h5>
                                                <span>Senior UX/UI Designer</span>
                                            </div>

                                        </div>
                                    </div>	{/* END TESTIMONIAL #5 */}


                                    {/* TESTIMONIAL #6 */}
                                    <div class="review-2">
                                        <div class="review-txt text-center">

                                            {/* Quote */}
                                            <div class="quote"><img src="assets/images/quote.png" alt="quote-img" /></div>

                                            {/* Author Avatar */}
                                            <div class="testimonial-avatar">
                                                <img src="assets/images/review-author-6.jpg" alt="testimonial-avatar" />
                                            </div>

                                            {/* Testimonial Text */}
                                            <p>An augue cubilia laoreet undo magna at risus suscipit egestas magna an ipsum ligula
                                                vitae and purus ipsum primis
                                            </p>

                                            {/* Testimonial Author */}
                                            <div class="review-author">
                                                <h5 class="h5-sm">Dan Hodges</h5>
                                                <span>Internet Surfer</span>
                                            </div>

                                        </div>
                                    </div>	{/* END TESTIMONIAL #6 */}


                                    {/* TESTIMONIAL #7 */}
                                    <div class="review-2">
                                        <div class="review-txt text-center">

                                            {/* Quote */}
                                            <div class="quote"><img src="assets/images/quote.png" alt="quote-img" /></div>

                                            {/* Author Avatar */}
                                            <div class="testimonial-avatar">
                                                <img src="assets/images/review-author-7.jpg" alt="testimonial-avatar" />
                                            </div>

                                            {/* Testimonial Text */}
                                            <p>Augue egestas volutpat egestas augue in cubilia laoreet magna suscipit luctus
                                                and dolor blandit vitae
                                            </p>

                                            {/* Testimonial Author */}
                                            <div class="review-author">
                                                <h5 class="h5-sm">Isabel M.</h5>
                                                <span>SEO Manager</span>
                                            </div>

                                        </div>
                                    </div>	{/* END TESTIMONIAL #7 */}


                                    {/* TESTIMONIAL #8 */}
                                    <div class="review-2">
                                        <div class="review-txt text-center">

                                            {/* Quote */}
                                            <div class="quote"><img src="assets/images/quote.png" alt="quote-img" /></div>

                                            {/* Author Avatar */}
                                            <div class="testimonial-avatar">
                                                <img src="assets/images/review-author-8.jpg" alt="testimonial-avatar" />
                                            </div>

                                            {/* Testimonial Text */}
                                            <p>Augue egestas volutpat egestas augue in cubilia laoreet magna suscipit luctus
                                                and dolor blandit vitae
                                            </p>

                                            {/* Testimonial Author */}
                                            <div class="review-author">
                                                <h5 class="h5-sm">Alex Ross</h5>
                                                <span>Patient</span>
                                            </div>

                                        </div>
                                    </div>	{/* END TESTIMONIAL #8 */}


                                    {/* TESTIMONIAL #9*/}
                                    <div class="review-2">
                                        <div class="review-txt text-center">

                                            {/* Quote */}
                                            <div class="quote"><img src="assets/images/quote.png" alt="quote-img" /></div>

                                            {/* Author Avatar */}
                                            <div class="testimonial-avatar">
                                                <img src="assets/images/review-author-9.jpg" alt="testimonial-avatar" />
                                            </div>

                                            {/* Testimonial Text */}
                                            <p>Augue egestas volutpat egestas augue in cubilia laoreet magna suscipit luctus
                                                magna dolor neque vitae
                                            </p>

                                            {/* Testimonial Author */}
                                            <div class="review-author">
                                                <h5 class="h5-sm">Alisa Milano</h5>
                                                <span>Housewife</span>
                                            </div>

                                        </div>
                                    </div>	{/* END TESTIMONIAL #9 */}

                                    </OwlCarousel>



                                </div>
                            </div>
                        </div>	{/* END TESTIMONIALS CONTENT */}


                    </div>	   {/* End container */}
                </section>	 {/* END TESTIMONIALS-2 */}






                {/* BANNER-7
============================================= */}
                <section id="banner-7" class="bg-fixed banner-section division">
                    <div class="container white-color">
                        <div class="row d-flex align-items-center">


                            {/* BANNER TEXT */}
                            <div class="col-md-8 col-lg-6 col-xl-5">
                                <div class="banner-txt wow fadeInUp" data-wow-delay="0.4s">

                                    {/* Title  */}
                                    <h2 class="h2-xs">Highest Quality Medical Treatment</h2>

                                    {/* Text */}
                                    <p>Egestas magna egestas magna ipsum vitae purus ipsum primis in cubilia laoreet augue
                                        egestas suscipit lectus mauris a lectus laoreet gestas neque undo luctus feugiat augue
                                        suscipit
                                    </p>

                                    {/* Button */}
                                    <a href="contact.php" class="btn btn-blue tra-white-hover mt-20">Free Consultation</a>

                                </div>
                            </div>	{/* END BANNER TEXT */}


                        </div>      {/* End row */}
                    </div>	    {/* End container */}
                </section>	{/* END BANNER-7 */}

                {/* VIDEO-1
============================================= */}
                <section id="video-1" class="bg-lightgrey wide-60 video-section division">
                    <div class="container">
                        <div class="row d-flex align-items-center">

                            {/* VIDEO LINK */}
                            <div class="col-lg-6">
                                <div class="video-preview mb-40 text-center wow fadeInUp" data-wow-delay="0.6s">

                                    {/* Change the link HERE!!! */}
                                    <a class="video-popup1" href="https://www.youtube.com/embed/SZEflIVnhH8">

                                        {/* Play Icon */}
                                        <div class="video-btn play-icon-blue">
                                            <div class="video-block-wrapper">
                                                <i class="fa fa-play"></i>
                                            </div>
                                        </div>

                                        {/* Preview */}
                                        <img class="img-fluid" src="assets/images/video-1.png" alt="video-photo" />

                                    </a>

                                </div>
                            </div>	{/* END VIDEO LINK */}

                            {/* VIDEO TEXT */}
                            <div class="col-lg-6">
                                <div class="txt-block pc-30 mb-40 wow fadeInUp" data-wow-delay="0.4s">

                                    {/* Section ID */}
                                    <span class="section-id blue-color">Modern Medicine</span>

                                    {/* Title */}
                                    <h3 class="h3-md steelblue-color">Better Technologies for Better Healthcare</h3>

                                    {/* CONTENT BOX #1 */}
                                    <div class="box-list">
                                        <div class="box-list-icon"><i class="fa fa-angle-double-right"></i></div>
                                        <p>Nemo ipsam egestas volute turpis dolores ut aliquam quaerat sodales sapien undo pretium
                                            purus feugiat dolor impedit
                                        </p>
                                    </div>

                                    {/* CONTENT BOX #2 */}
                                    <div class="box-list">
                                        <div class="box-list-icon"><i class="fa fa-angle-double-right"></i></div>
                                        <p>Gravida quis vehicula magna luctus tempor quisque vel laoreet turpis urna augue,
                                            viverra a augue eget dictum
                                        </p>
                                    </div>

                                    {/* CONTENT BOX #3 */}
                                    <div class="box-list">
                                        <div class="box-list-icon"><i class="fa fa-angle-double-right"></i></div>
                                        <p>Nemo ipsam egestas volute turpis dolores ut aliquam quaerat sodales sapien undo pretium
                                            purus feugiat dolor impedit
                                        </p>
                                    </div>

                                </div>
                            </div>



                        </div>	    {/* End row */}
                    </div>	    {/* End container */}
                </section>	 {/* END VIDEO-1 */}







                {/* BANNER-6
============================================= */}
                <section id="banner-6" class="bg-scroll banner-section division">
                    <div class="container white-color">
                        <div class="row d-flex align-items-center">


                            {/* BANNER TEXT */}
                            <div class="col-lg-9 icon-xl">

                                {/* Icon */}
                                <span class="flaticon-072-hospital-5"></span>

                                {/* Text */}
                                <div class="banner-txt">
                                    <h4 class="h4-lg">Do you search a good and quality medical clinic? We care about your health 24/7</h4>
                                    <p class="p-md">Donec vel sapien augue integer urna vel turpis cursus porta luctus</p>
                                </div>

                            </div>


                            {/* BANNER BUTTON */}
                            <div class="col-lg-3 ">
                                <div class="banner-btn text-right">
                                    <a href="contact.php" class="btn btn-md btn-tra-white blue-hover">Get In Touch</a>
                                </div>
                            </div>


                        </div>      {/* End row */}
                    </div>	    {/* End container */}
                </section>	{/* END BANNER-6 */}




                {/* FOOTER-3
============================================= */}
                {/* END FOOTER-3 */}



            </div>
            )

        </>
    )
}