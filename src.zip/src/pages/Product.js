
import React from 'react';
import { Link } from 'react-router-dom'
import Popper from 'popper.js';
import Dropdown from 'react-dropdown';
import 'react-dropdown/style.css';
export default function Product() {
    return (
        <>

            <div id="page" class="page">




                {/* HEADER
    ============================================= */}
                {/* END HEADER */}




                {/* BREADCRUMB
    ============================================= */}
                <div id="breadcrumb" class="division">
                    <div class="container">
                        <div class="row">
                            <div class="col">
                                <div class=" breadcrumb-holder">

                                    {/* Breadcrumb Nav */}
                                    <nav aria-label="breadcrumb">
                                        <ol class="breadcrumb">
                                            <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                            <li class="breadcrumb-item active" aria-current="page">Products</li>
                                        </ol>
                                    </nav>

                                    {/* Title */}
                                    <h4 class="h4-sm steelblue-color">Products</h4>

                                </div>
                            </div>
                        </div> {/* End row */}
                    </div> {/* End container */}
                </div> {/* END BREADCRUMB */}




                {/* APPOINTMENT PAGE
    ============================================= */}
                <div class="pt-100">
                    <div class="container">
                        <div class="row">


                            <div class="col-lg-10 offset-lg-1 section-title">

                                {/* Title 	*/}
                                <h3 class="h3-md steelblue-color">Our Products</h3>

                                {/* Text */}
                                <p>Aliquam a augue suscipit, luctus neque purus ipsum neque dolor primis libero at tempus,
                                    blandit posuere ligula varius congue cursus porta feugiat
                                </p>

                            </div>

                            <div class="col-lg-12">
                                <div class="filter-section">
                                    <div class="dropdown">
                                        <button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown">
                                            Dropdown button
                                        </button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item" href="#">Link 1</a>
                                            <a class="dropdown-item" href="#">Link 2</a>
                                            <a class="dropdown-item" href="#">Link 3</a>
                                            <div class="dropdown-divider"></div>
                                            <a class="dropdown-item" href="#">Another link</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-4 col-sm-6">
                                <div class="sbox-5 product-card">

                                    {/* Image */}
                                    <img class="img-fluid" src="assets/images/prod.png" alt="content-image" />

                                    {/* Text */}
                                    <div class="sbox-5-txt">


                                        {/* Title */}
                                        <h5 class="h5-sm blue-color">Whole Genome Sequencing</h5>
                                        <span><i class="fa fa-inr"> 7999/-</i>&nbsp;&nbsp;&nbsp;&nbsp; or
                                            &nbsp;&nbsp;&nbsp;&nbsp;</span>
                                        <i class="fa fa-btc" aria-hidden="true"> 18</i>

                                        {/* Text */}
                                        <p>Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor
                                            tempus feugiat dolor lacinia cubilia curae integer congue leo metus
                                        </p>
                                        <button class="btn btn-blue blue-hover mt-20">Buy Now</button>

                                    </div>

                                </div>
                            </div>


                            <div class="col-lg-4 col-sm-6">
                                {/* SERVICE BOX #2 */}
                                <div class="sbox-5 product-card">

                                    {/* Image */}
                                    <img class="img-fluid" src="assets/images/prod.png" alt="content-image" />

                                    {/* Text */}
                                    <div class="sbox-5-txt">


                                        {/* Title */}
                                        <h5 class="h5-sm blue-color">Whole Genome Sequencing</h5>
                                        <span><i class="fa fa-inr"> 7999/-</i>&nbsp;&nbsp;&nbsp;&nbsp; or
                                            &nbsp;&nbsp;&nbsp;&nbsp;</span>
                                        <i class="fa fa-btc" aria-hidden="true"> 18</i>

                                        {/* Text */}
                                        <p>Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor
                                            tempus feugiat dolor lacinia cubilia curae integer congue leo metus
                                        </p>
                                        <button class="btn btn-blue blue-hover mt-20">Buy Now</button>

                                    </div>

                                </div>
                            </div>

                            <div class="col-lg-4 col-sm-6">
                                {/* SERVICE BOX #3 */}
                                <div class="sbox-5 product-card">

                                    {/* Image */}
                                    <img class="img-fluid" src="assets/images/prod.png" alt="content-image" />

                                    {/* Text */}
                                    <div class="sbox-5-txt">


                                        {/* Title */}
                                        <h5 class="h5-sm blue-color">Whole Genome Sequencing</h5>
                                        <span><i class="fa fa-inr"> 7999/-</i>&nbsp;&nbsp;&nbsp;&nbsp; or
                                            &nbsp;&nbsp;&nbsp;&nbsp;</span>
                                        <i class="fa fa-btc" aria-hidden="true"> 18</i>

                                        {/* Text */}
                                        <p>Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor
                                            tempus feugiat dolor lacinia cubilia curae integer congue leo metus
                                        </p>
                                        <button class="btn btn-blue blue-hover mt-20">Buy Now</button>

                                    </div>

                                </div>
                            </div>

                            <div class="col-lg-4 col-sm-6">
                                {/* SERVICE BOX #4 */}
                                <div class="sbox-5 product-card">

                                    {/* Image */}
                                    <img class="img-fluid" src="assets/images/prod.png" alt="content-image" />

                                    {/* Text */}
                                    <div class="sbox-5-txt">


                                        {/* Title */}
                                        <h5 class="h5-sm blue-color">Whole Genome Sequencing</h5>
                                        <span><i class="fa fa-inr"> 7999/-</i>&nbsp;&nbsp;&nbsp;&nbsp; or
                                            &nbsp;&nbsp;&nbsp;&nbsp;</span>
                                        <i class="fa fa-btc" aria-hidden="true"> 18</i>

                                        {/* Text */}
                                        <p>Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor
                                            tempus feugiat dolor lacinia cubilia curae integer congue leo metus
                                        </p>
                                        <button class="btn btn-blue blue-hover mt-20">Buy Now</button>

                                    </div>

                                </div>
                            </div>

                            <div class="col-lg-4 col-sm-6">
                                {/* SERVICE BOX #5 */}
                                <div class="sbox-5 product-card">

                                    {/* Image */}
                                    <img class="img-fluid" src="assets/images/prod.png" alt="content-image" />

                                    {/* Text */}
                                    <div class="sbox-5-txt">


                                        {/* Title */}
                                        <h5 class="h5-sm blue-color">Whole Genome Sequencing</h5>
                                        <span><i class="fa fa-inr"> 7999/-</i>&nbsp;&nbsp;&nbsp;&nbsp; or
                                            &nbsp;&nbsp;&nbsp;&nbsp;</span>
                                        <i class="fa fa-btc" aria-hidden="true"> 18</i>

                                        {/* Text */}
                                        <p>Porta semper lacus cursus, feugiat primis ultrice in ligula risus auctor
                                            tempus feugiat dolor lacinia cubilia curae integer congue leo metus
                                        </p>
                                        <button class="btn btn-blue blue-hover mt-20">Buy Now</button>

                                    </div>

                                </div>
                            </div>









                        </div> {/* End row */}
                    </div> {/* End container */}
                </div> {/* END APPOINTMENT PAGE */}




                {/* FOOTER-3
    ============================================= */}
                {/* END FOOTER-3 */}


                {/* The Modal */}

            </div>

        </>
    )
}

