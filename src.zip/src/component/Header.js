
import React from 'react';
import { Link } from 'react-router-dom'
export default function Header() {
    return (
        <>
            <div>
            
			<nav class="navbar navbar-expand-lg navbar-light bg-light">
      <a class="navbar-brand" href="index.html">
      <img src="assets/img/tios.png" alt="logo" />
      </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav m-auto">
        <li class="nav-item active">
          <a class="nav-link" href="product.html">Shop <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="all-samples-page-1.html">Try first</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="all-collaction.html"> Collections</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="all-sample-brand.html">Brands</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.html">About Us</a>
        </li>
      </ul>
      <div class="nav-r form-inline my-2 my-lg-0" id="mobile-search">
        <div class="collections-btn">
          <a href="#" class="common-btn">5  tios points</a>
        </div>
        <ul>
          <li>
            <a href="#" class="search-toggle">
              <img src="./assets/img/search.png" class=" search-icon icon-search" alt="" />
              <div class="search-box-wrap">
                <div class="searchform" role="search">
                  <form>
                    <input type="text" name="q" id="search-terms" placeholder="Search..." class="search-field" />
                    <input type="submit" class="search-submit default-btn" value="submit" />
                  </form>
                </div>
              </div>
            </a>
          </li>
          <li><a href="login.html"><img src="./assets/img/Icon.png" alt="" /></a></li>
          <li><a href="view-cart.html"><img src="./assets/img/cart.png" alt="" /></a></li>
        </ul>
      </div>
	   </div>
    </nav>

            </div>
        
  
        </>
    )
}

